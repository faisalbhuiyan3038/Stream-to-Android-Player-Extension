/*! Stream to Android Player | GPL-3.0-or-later | see LICENSE.md | source: https://github.com/faisalbhuiyan3038/Stream-to-Android-Player-Extension */
(()=>{typeof browser>"u"&&(globalThis.browser=chrome);let f=[],g=[],b=null,E=null;const C=new Map,q=new Set,Y=/\.(m3u8?|mpd|mp4|ts|vtt|srt|ass|ssa)(\?|#|$)|manifest|playlist|master\.json|urlset|\/video\/|\/media\/|\/stream\//i,N={showCopyIcon:!0,showPlayIcon:!0,showDownloadIcon:!0,defaultTapAction:"default",androidPlayer:"auto",buttonVisibility:"always",enabled:!0,whitelist:[],blacklist:[]};let p={...N},y="win";window.addEventListener("beforeunload",()=>{f=[],b&&(b.disconnect(),b=null),E&&clearTimeout(E);const t=document.getElementById("video-handler-menu"),e=document.getElementById("video-handler-button");t&&t.remove(),e&&e.remove()});function X(){const t=document.createElement("div");return t.id="video-handler-menu",t.style.display="none",document.body.appendChild(t),t}function G(t,e){if(y==="android"){const i=g[0]&&g[0].url;StreamShared.shareToAndroid(window,t,e,p.androidPlayer,i)}else navigator.clipboard.writeText(t).catch(()=>{})}function R(t){return C.get(t.url)||t.url}function P(){const t=document.getElementById("video-handler-menu")||X();if(t.replaceChildren(...f.map(e=>{const i=e.displayName||e.name,n=e.title||e.pageTitle||"",o=document.createElement("div");o.className="stream-item",o.dataset.url=e.url,o.title=e.url;const s=document.createElement("div");s.className="stream-info";const r=document.createElement("span");r.className="stream-name",r.textContent=i,s.appendChild(r);const d=document.createElement("div");if(d.className="stream-badges",e.quality){const a=document.createElement("span");a.className="quality-badge",a.textContent=e.quality,d.appendChild(a)}if(e.duration){const a=document.createElement("span");a.className="duration-badge",a.textContent=StreamShared.formatDuration(e.duration),d.appendChild(a)}if(g.length>0){const a=document.createElement("span");a.className="sub-badge",a.textContent=`CC ${g.length}`,a.title=g.map(l=>l.label).join(`
`),d.appendChild(a)}if(e.variants&&e.variants.length>1){const a=document.createElement("select");a.className="v-quality",a.title="Quality";const l=document.createElement("option");l.value="",l.textContent="Auto",a.appendChild(l);for(const u of e.variants){const m=document.createElement("option");m.value=u.url,m.textContent=u.label,a.appendChild(m)}a.value=C.get(e.url)||"",a.onclick=u=>u.stopPropagation(),a.onchange=()=>{a.value?C.set(e.url,a.value):C.delete(e.url)},d.appendChild(a)}if(s.appendChild(d),n){const a=document.createElement("span");a.className="stream-subtitle",a.textContent=n,s.appendChild(a)}const c=document.createElement("div");c.className="stream-actions";const h=T("v-action-share",y==="android"?"Share":"Open in External Player",y==="android"?"📤":"🖥️");return c.appendChild(h),p.showCopyIcon!==!1&&c.appendChild(T("v-action-copy","Copy URL","📋")),p.showPlayIcon!==!1&&c.appendChild(T("v-action-play","Play in Browser","▶️")),p.showDownloadIcon&&c.appendChild(T("v-action-download","Download as MP4","⬇️")),o.appendChild(s),o.appendChild(c),o})),!document.getElementById("video-handler-styles")){const e=document.createElement("style");e.id="video-handler-styles",e.textContent=`
      .stream-item {
        display: flex !important;
        justify-content: space-between !important;
        align-items: center !important;
        padding: 8px 12px !important;
        cursor: pointer !important;
        border-bottom: 1px solid rgba(255,255,255,0.08) !important;
        transition: background 0.15s !important;
      }
      .stream-item:last-child { border-bottom: none !important; }
      .stream-item:hover { background: rgba(255,255,255,0.08) !important; }
      .stream-info {
        flex: 1 !important;
        min-width: 0 !important;
        display: flex !important;
        flex-direction: column !important;
        gap: 2px !important;
      }
      .stream-name {
        overflow: hidden !important;
        text-overflow: ellipsis !important;
        white-space: nowrap !important;
        font-size: 13px !important;
      }
      .stream-subtitle {
        font-size: 11px !important;
        color: rgba(255,255,255,0.5) !important;
        overflow: hidden !important;
        text-overflow: ellipsis !important;
        white-space: nowrap !important;
      }
      .stream-badges {
        display: flex !important;
        gap: 6px !important;
        align-items: center !important;
        margin-top: 2px !important;
        flex-wrap: wrap !important;
      }
      .quality-badge, .duration-badge, .sub-badge {
        display: inline-block !important;
        color: white !important;
        padding: 1px 5px !important;
        border-radius: 3px !important;
        font-size: 10px !important;
        font-weight: 600 !important;
      }
      .quality-badge {
        background: #4CAF50 !important;
      }
      .duration-badge {
        background: #2196F3 !important;
      }
      .sub-badge {
        background: #9C27B0 !important;
      }
      .v-quality {
        background: rgba(255,255,255,0.12) !important;
        color: white !important;
        border: none !important;
        border-radius: 3px !important;
        font-size: 10px !important;
        padding: 1px 2px !important;
        cursor: pointer !important;
      }
      .v-quality option { color: black !important; }
      .stream-actions {
        display: flex !important;
        gap: 6px !important;
        margin-left: 12px !important;
        flex-shrink: 0 !important;
        visibility: visible !important;
        opacity: 1 !important;
      }
      .v-handler-btn {
        all: unset !important;
        box-sizing: border-box !important;
        background: none !important;
        border: none !important;
        cursor: pointer !important;
        padding: 4px !important;
        font-size: 15px !important;
        line-height: 1 !important;
        border-radius: 4px !important;
        transition: background 0.15s !important;
        display: inline-flex !important;
        align-items: center !important;
        justify-content: center !important;
        color: white !important;
        min-width: 23px !important;
        min-height: 23px !important;
        visibility: visible !important;
        opacity: 1 !important;
      }
      .v-handler-btn:hover {
        background: rgba(255,255,255,0.15) !important;
      }
      @media (pointer: coarse) {
        #video-handler-menu { max-width: 92vw !important; }
        .stream-item { padding: 12px 12px !important; }
        .stream-name { font-size: 15px !important; }
        .v-handler-btn { min-width: 44px !important; min-height: 44px !important; font-size: 22px !important; }
        .v-quality { font-size: 14px !important; padding: 4px 6px !important; min-height: 40px !important; min-width: 64px !important; }
        .quality-badge, .duration-badge, .sub-badge { font-size: 12px !important; }
      }
    `,document.head.appendChild(e)}t.querySelectorAll(".stream-item").forEach((e,i)=>{const n=f[i];if(!n)return;const o=(l,u)=>{const m=l.textContent;l.textContent="❌",l.title=u||"Failed",setTimeout(()=>l.textContent=m,1500)},s=(l,u)=>{const m={type:l,url:R(n),streamUrl:n.url};if(!u){browser.runtime.sendMessage(m).catch(()=>{});return}const j=u.textContent;u.textContent="⏳",browser.runtime.sendMessage(m).then(B=>{B&&B.success?(u.textContent="✅",setTimeout(()=>u.textContent=j,1500)):o(u,B&&B.error)}).catch(()=>o(u,"No response from the extension"))},r=(l,u)=>{const m=R(n);l==="copy"?navigator.clipboard.writeText(m).catch(()=>{}):l==="browser"?s("openWebPlayer",null):l==="external"?s("openExternalPlayer",u):l==="download"?s("downloadStream",u):G(m,n.title||n.displayName||n.name||"")};e.onclick=()=>{let l=p.defaultTapAction||"default";l==="default"&&(l=y==="android"?"share":"copy"),r(l,null)};const d=e.querySelector(".v-action-share");d&&(d.onclick=l=>{l.stopPropagation(),r(y==="android"?"share":"external",d)});const c=e.querySelector(".v-action-copy");c&&(c.onclick=l=>{l.stopPropagation();const u=c.textContent;c.textContent="✅",setTimeout(()=>c.textContent=u,1e3),r("copy",null)});const h=e.querySelector(".v-action-play");h&&(h.onclick=l=>{l.stopPropagation(),r("browser",null)});const a=e.querySelector(".v-action-download");a&&(a.onclick=l=>{l.stopPropagation(),r("download",a)})})}function T(t,e,i){const n=document.createElement("button");return n.type="button",n.className=`v-handler-btn ${t}`,n.title=e,n.textContent=i,n}function D(t={}){p={...N,...t.settings||p||{}},y=t.platform||y}const v=48,I=20,A={side:"right",yRatio:1};let x={global:{...A},sites:{}},z=0,O=null;function $(t){return!t||t.side!=="left"&&t.side!=="right"||typeof t.yRatio!="number"||!isFinite(t.yRatio)?null:{side:t.side,yRatio:Math.min(1,Math.max(0,t.yRatio))}}function U(t){const e={global:{...A},sites:{}};if(t){e.global=$(t.global)||e.global;for(const[i,n]of Object.entries(t.sites||{})){const o=$(n);o&&(e.sites[i]=o)}}return e}function K(){return x.sites[location.hostname]||x.global}function M(){return{width:document.documentElement.clientWidth||window.innerWidth,height:window.innerHeight}}function k(t,e,i){return Math.min(Math.max(t,e),Math.max(e,i))}function w(t=document.getElementById("video-handler-button")){if(!t)return;const{width:e,height:i}=M(),n=K(),o=n.side==="left"?I:e-v-I,s=k(n.yRatio*(i-v),I,i-v-I);t.style.left=`${Math.max(0,o)}px`,t.style.top=`${s}px`,t.style.right="auto",t.style.bottom="auto",_()}function _(){const t=document.getElementById("video-handler-button"),e=document.getElementById("video-handler-menu");if(!t||!e||e.style.display==="none")return;const{width:i,height:n}=M(),o=t.getBoundingClientRect(),s=8,r=8,d=o.top+o.height/2>n/2,c=d?o.top-s-r:n-o.bottom-s-r;e.style.maxHeight=`${Math.max(120,Math.min(350,c))}px`,d?(e.style.top="auto",e.style.bottom=`${n-o.top+s}px`):(e.style.bottom="auto",e.style.top=`${o.bottom+s}px`),o.left+o.width/2>i/2?(e.style.left="auto",e.style.right=`${Math.max(r,i-o.right)}px`):(e.style.right="auto",e.style.left=`${Math.max(r,o.left)}px`)}function F(){const t=document.getElementById("video-handler-menu");if(!t)return;const e=t.style.display==="none";t.style.display=e?"block":"none",e&&_(),S()}function S(){const t=document.getElementById("video-handler-button");t&&(t.classList.remove("v-faded"),clearTimeout(O),p.buttonVisibility==="fade"&&(O=setTimeout(()=>{const e=document.getElementById("video-handler-menu");if(e&&e.style.display!=="none"){S();return}t.classList.add("v-faded")},3e3)))}function Q(){if(p.enabled===!1)return!0;const t=location.hostname;return!t||StreamShared.matchesDomainList(t,p.whitelist||[])?!1:StreamShared.matchesDomainList(t,p.blacklist||[])}function L(){const t=document.getElementById("video-handler-button");if(!t)return;const e=f.length===0||p.buttonVisibility==="never"||!!document.fullscreenElement||Q();if(t.style.display=e?"none":"flex",e){const i=document.getElementById("video-handler-menu");i&&(i.style.display="none")}else w(t),S()}function Z(t){x.sites[location.hostname]=t,browser.storage.local.set({buttonLayout:x}).catch(()=>{})}function J(t){let n=null;const o=()=>{n.active=!0,t.classList.add("v-dragging");const r=document.getElementById("video-handler-menu");r&&(r.style.display="none"),navigator.vibrate&&n.type==="touch"&&navigator.vibrate(15)};t.addEventListener("pointerdown",r=>{if(r.pointerType==="mouse"&&r.button!==0)return;const d=t.getBoundingClientRect();n={id:r.pointerId,startX:r.clientX,startY:r.clientY,left:d.left,top:d.top,active:!1,type:r.pointerType,timer:null},r.pointerType==="touch"&&(n.timer=setTimeout(()=>{n&&!n.active&&o()},350));try{t.setPointerCapture(r.pointerId)}catch{}}),t.addEventListener("pointermove",r=>{if(!n||r.pointerId!==n.id)return;const d=r.clientX-n.startX,c=r.clientY-n.startY;if(!n.active){if(Math.hypot(d,c)<6)return;if(n.type==="touch"){clearTimeout(n.timer),n=null;return}o()}const{width:h,height:a}=M();t.style.left=`${k(n.left+d,0,h-v)}px`,t.style.top=`${k(n.top+c,0,a-v)}px`,t.style.right="auto",t.style.bottom="auto",r.preventDefault()});const s=r=>{if(!n||r.pointerId!==n.id)return;clearTimeout(n.timer);const d=n.active;n=null,t.classList.remove("v-dragging");try{t.releasePointerCapture(r.pointerId)}catch{}if(!d)return;z=Date.now();const{width:c,height:h}=M(),a=t.getBoundingClientRect(),l={side:a.left+a.width/2<c/2?"left":"right",yRatio:k(a.top/Math.max(1,h-v),0,1)};Z(l),w(t)};t.addEventListener("pointerup",s),t.addEventListener("pointercancel",s)}function tt(){const t=document.createElement("div");t.id="video-handler-button",t.innerHTML="▶️",t.style.display="none",t.setAttribute("role","button"),t.setAttribute("tabindex","0"),t.setAttribute("aria-label","Detected streams (drag to move)"),document.body.appendChild(t),w(t),J(t);let e=0;return t.addEventListener("click",i=>{if(i.preventDefault(),i.stopPropagation(),Date.now()-z<150)return;const n=Date.now();n-e<300||(e=n,F())}),t.addEventListener("keydown",i=>{(i.key==="Enter"||i.key===" ")&&(i.preventDefault(),F())}),t.addEventListener("pointerenter",S),t.addEventListener("focus",S),t}browser.storage.local.get("buttonLayout").then(t=>{x=U(t.buttonLayout),w()}).catch(()=>{}),window.addEventListener("resize",()=>w()),document.addEventListener("fullscreenchange",L);function V(){if(b)return;const t=()=>{E&&clearTimeout(E),E=setTimeout(()=>{const e=[],i=[];document.querySelectorAll("video").forEach(o=>{o.src&&o.src.startsWith("http")&&e.push({url:o.src,duration:o.duration}),o.querySelectorAll("source").forEach(s=>{s.src&&s.src.startsWith("http")&&e.push({url:s.src,duration:o.duration})}),o.querySelectorAll("track").forEach(s=>{s.src&&s.src.startsWith("http")&&i.push({url:s.src,label:s.label||"",lang:s.srclang||""})})}),document.querySelectorAll("[data-source]").forEach(o=>{const s=o.getAttribute("data-source");s&&s.startsWith("http")&&e.push({url:s,duration:null})});const n=[];for(const o of performance.getEntriesByType("resource"))q.has(o.name)||!Y.test(o.name)||o.responseStatus>=400||(q.add(o.name),n.push(o.name));(e.length>0||i.length>0||n.length>0)&&browser.runtime.sendMessage({type:"videoSourcesFound",sources:e,tracks:i,resources:n}).catch(()=>{})},1e3)};b=new MutationObserver(t),b.observe(document.body,{childList:!0,subtree:!0}),t()}function H(t,e){f=t,g=e||[];const i=()=>{document.getElementById("video-handler-button")||tt(),P(),L()};browser.runtime.sendMessage({type:"getSettings"}).then(n=>{n&&D(n),i()}).catch(i)}browser.runtime.onMessage.addListener((t,e,i)=>{if(t.type==="streamDetected")H(t.streams,t.subtitles);else if(t.type==="streamsCleared"){f=[],g=[],C.clear();const n=document.getElementById("video-handler-menu");n&&(n.style.display="none",n.replaceChildren()),L()}});function et(){browser.runtime.sendMessage({type:"getStreams",docUrl:location.href}).then(t=>{t&&t.streams&&t.streams.length>0&&f.length===0&&H(t.streams,t.subtitles)}).catch(()=>{})}browser.storage.onChanged.addListener((t,e)=>{e==="local"&&(t.settings&&(D({settings:t.settings.newValue}),document.getElementById("video-handler-menu")&&P(),L()),t.buttonLayout&&(x=U(t.buttonLayout.newValue),w()))});function W(){browser.storage.local.get("settings").then(t=>{!t||!t.settings||(D({settings:t.settings}),document.getElementById("video-handler-menu")&&P(),L())}).catch(()=>{})}document.addEventListener("visibilitychange",()=>{document.visibilityState==="visible"&&W()}),window.addEventListener("pageshow",t=>{t.persisted&&W()}),document.readyState==="loading"?document.addEventListener("DOMContentLoaded",V):V(),et();})();
