/*! Stream to Android Player | GPL-3.0-or-later | see LICENSE.md | source: https://github.com/faisalbhuiyan3038/Stream-to-Android-Player-Extension */
(()=>{const s=new Map;self.onmessage=t=>{const{id:e,ms:a,cancel:l}=t.data||{};if(l){clearTimeout(s.get(e)),s.delete(e);return}s.set(e,setTimeout(()=>{s.delete(e),self.postMessage(e)},a))};})();
