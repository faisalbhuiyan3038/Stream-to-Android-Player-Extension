// Browser tests for the Chromium build. Loads a staged copy of the extension with the Chrome
// manifest (tests/e2e/stage.js). Needs a headed browser: run under xvfb on Linux CI.
//   npm run test:e2e                 local site only, no internet
//   E2E_NETWORK=1 npm run test:e2e   also plays real public HLS/DASH streams
const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const os = require('os');
const path = require('path');
const fs = require('fs');
const { chromium } = require('playwright');
const { startServer, ORIGIN } = require('./server');

const { stageExtension } = require('./stage');

let EXT; // staged copy with the Chrome manifest (set in before())
const NETWORK = process.env.E2E_NETWORK === '1';
const sleep = ms => new Promise(r => setTimeout(r, ms));

let ctx, sw, extId, site, profileDir;

async function until(fn, { timeout = 10000, interval = 200 } = {}) {
  const end = Date.now() + timeout;
  let last;
  while (Date.now() < end) {
    last = await fn();
    if (last) return last;
    await sleep(interval);
  }
  return last;
}

const readItems = page => page.$$eval('.stream-item', els => els.map(e => ({
  name: e.querySelector('.stream-name').textContent,
  quality: (e.querySelector('.quality-badge') || {}).textContent || '',
  duration: (e.querySelector('.duration-badge') || {}).textContent || '',
  subs: (e.querySelector('.sub-badge') || {}).textContent || '',
  variants: [...e.querySelectorAll('.v-quality option')].map(o => o.textContent),
  url: e.dataset.url
})));

async function openSite(route, { settle = 0 } = {}) {
  const page = await ctx.newPage();
  await page.goto(ORIGIN + route, { waitUntil: 'domcontentloaded' });
  if (settle) await sleep(settle);
  return page;
}

async function setSettings(partial) {
  await sw.evaluate(async (s) => {
    const r = await chrome.storage.local.get('settings');
    await chrome.storage.local.set({ settings: { ...(r.settings || {}), ...s } });
  }, partial);
  await sleep(300);
}

const tabIdOf = page => sw.evaluate(async (u) => (await chrome.tabs.query({})).find(t => t.url === u).id, page.url());

before(async () => {
  site = await startServer();
  EXT = stageExtension('chrome');
  profileDir = fs.mkdtempSync(path.join(os.tmpdir(), 'sap-e2e-'));
  const headless = process.env.HEADLESS === '1';
  ctx = await chromium.launchPersistentContext(profileDir, {
    executablePath: process.env.CHROMIUM_BIN || undefined, // a preinstalled Chromium when Playwright's own is missing
    channel: headless ? 'chromium' : undefined,
    headless,
    permissions: ['clipboard-read', 'clipboard-write'],
    args: [`--disable-extensions-except=${EXT}`, `--load-extension=${EXT}`]
  });
  sw = ctx.serviceWorkers()[0] || await ctx.waitForEvent('serviceworker', { timeout: 20000 });
  extId = sw.url().split('/')[2];
});

after(async () => {
  if (ctx) await ctx.close();
  if (site) site.server.close();
  if (profileDir) fs.rmSync(profileDir, { recursive: true, force: true });
  if (EXT) fs.rmSync(EXT, { recursive: true, force: true });
});

// ── detection ────────────────────────────────────────────────────────────────

test('detects an m3u8 fetched at page load (first tab after start, then repeated)', async () => {
  for (let i = 0; i < 3; i++) {
    const page = await openSite(`/p/early?n=${i}`);
    const items = await until(async () => { const r = await readItems(page); return r.length ? r : null; });
    assert.ok(items && items.length === 1, `round ${i}: expected 1 stream, got ${JSON.stringify(items)}`);
    assert.equal(items[0].duration, '0:10');
    await page.close();
  }
});

test('detects <video src> and parses quality from the URL', async () => {
  const page = await openSite('/p/video');
  const items = await until(async () => { const r = await readItems(page); return r.length ? r : null; });
  assert.equal(items[0].quality, '1080p');
  await page.close();
});

test('keeps a standalone .ts stream', async () => {
  const page = await openSite('/p/ts-only');
  const items = await until(async () => { const r = await readItems(page); return r.length ? r : null; });
  assert.equal(items.length, 1);
  assert.match(items[0].name, /\(ts\)/);
  await page.close();
});

test('hides .ts segments that belong to a detected playlist (separate host too)', async () => {
  const page = await openSite('/p/segments');
  await until(async () => (await readItems(page)).length >= 1);
  await sleep(2500); // segments are requested 300 ms after the playlist
  const items = await readItems(page);
  assert.equal(items.length, 1, JSON.stringify(items));
  assert.match(items[0].name, /\(m3u8\)/);
  await page.close();
});

test('removes .ts segments that arrived before their playlist', async () => {
  const page = await openSite('/p/ts-before-playlist');
  await until(async () => (await readItems(page)).length >= 1);
  await sleep(2500);
  const items = await readItems(page);
  assert.equal(items.length, 1, JSON.stringify(items));
  assert.match(items[0].name, /\(m3u8\)/);
  await page.close();
});

test('master playlist: real quality, variants and duration', async () => {
  const page = await openSite('/p/master');
  const items = await until(async () => {
    const r = await readItems(page);
    return r.length && r[0].variants.length && r[0].duration ? r : null;
  });
  assert.ok(items, 'variants/duration never arrived');
  assert.equal(items[0].quality, '1080p');
  assert.deepEqual(items[0].variants, ['Auto', '1080p', '720p', '480p']);
  assert.equal(items[0].duration, '1:00');
  await page.close();
});

test('MPD: quality and duration from the manifest', async () => {
  const page = await openSite('/p/dash');
  const items = await until(async () => {
    const r = await readItems(page);
    return r.length && r[0].duration ? r : null;
  });
  assert.equal(items[0].quality, '1080p');
  assert.equal(items[0].duration, '1:30');
  await page.close();
});

test('navigating to a new page clears the previous page streams and badge', async () => {
  const page = await openSite('/p/video');
  await until(async () => (await readItems(page)).length === 1);
  const tabId = await tabIdOf(page);
  assert.equal(await sw.evaluate(id => chrome.action.getBadgeText({ tabId: id }), tabId), '1');
  await page.goto(ORIGIN + '/p/blank');
  await sleep(1500);
  const stored = await sw.evaluate(async id => ((await chrome.storage.local.get('detectedStreams')).detectedStreams || []).find(e => e[0] === id), tabId);
  assert.ok(!stored || stored[1].length === 0, 'old streams still stored');
  assert.equal(await sw.evaluate(id => chrome.action.getBadgeText({ tabId: id }), tabId), '');
  await page.close();
});

// ── subtitles ────────────────────────────────────────────────────────────────

test('collects <track> and network subtitles and shows a CC badge', async () => {
  const page = await openSite('/p/subs');
  const items = await until(async () => {
    const r = await readItems(page);
    return r.length && r[0].subs === 'CC 2' ? r : null;
  });
  assert.ok(items, 'CC 2 badge never appeared');
  await page.close();
});

test('web player keeps the chosen engine (Vidstack) and passes the subtitles with language labels', async () => {
  await setSettings({ webPlayerEngine: 'vidstack' });
  const page = await openSite('/p/subs');
  await until(async () => (await readItems(page)).length && (await page.$('.sub-badge')));
  await page.click('#video-handler-button');
  const [player] = await Promise.all([ctx.waitForEvent('page'), page.click('.v-action-play')]);
  await until(() => player.url().includes('player.html'));
  assert.match(player.url(), /\/player\.html\?/);
  const subs = JSON.parse(new URL(player.url()).searchParams.get('subs'));
  assert.equal(subs.length, 2);
  // <track label="English"> keeps its label; fr.srt gets its language from the file name
  assert.deepEqual(subs.map(s => `${s.lang}|${s.label}`).sort(), ['en|English', 'fr|French']);
  await player.close();
  await page.close();
});

// Both web players convert SRT (Windows-1252), ASS and TTML to WebVTT and attach them.
const SUBS_MIX = [
  { url: `${ORIGIN}/subs/cp1252.srt`, label: 'SRT', lang: 'fr' },
  { url: `${ORIGIN}/subs/styled.ass`, label: 'ASS', lang: 'en' },
  { url: `${ORIGIN}/subs/caps.ttml`, label: 'TTML', lang: 'de' }
];
const subsQuery = () => `url=${encodeURIComponent(ORIGIN + '/media/real.webm')}&subs=${encodeURIComponent(JSON.stringify(SUBS_MIX))}`;
const readStatus = page => page.evaluate(() => (window._subtitleStatus || []).map(s => `${s.label}:${s.format}:${s.via}`));

test('Vidstack page: SRT (cp1252), ASS and TTML subtitles are converted and loaded', async () => {
  const page = await ctx.newPage();
  await page.goto(`chrome-extension://${extId}/player.html?${subsQuery()}`);
  const done = await until(async () => { const s = await readStatus(page); return s.length === 3 && !s.some(x => x.endsWith(':pending')); }, { timeout: 20000 });
  assert.ok(done, `subtitles never processed: ${JSON.stringify(await readStatus(page))}`);
  assert.deepEqual(await readStatus(page), ['SRT:srt:converted', 'ASS:ass:converted', 'TTML:ttml:converted']);
  const tracks = await page.evaluate(() => document.querySelector('media-player').textTracks.toArray().map(t => `${t.label}|${t.language}`));
  assert.deepEqual(tracks, ['SRT|fr', 'ASS|en', 'TTML|de']);
  const firstCue = await until(() => page.evaluate(() => {
    const t = document.querySelector('media-player').textTracks.toArray()[0];
    return t && t.cues.length ? t.cues[0].text : null;
  }), { timeout: 10000 });
  assert.equal(firstCue, 'Café “quoted”');
  await page.close();
});

test('Shaka page: SRT (cp1252), ASS and TTML subtitles are converted and loaded', async () => {
  const page = await ctx.newPage();
  await page.goto(`chrome-extension://${extId}/player-shaka.html?${subsQuery()}`);
  const done = await until(async () => { const s = await readStatus(page); return s.length === 3 && !s.some(x => x.endsWith(':pending')); }, { timeout: 20000 });
  assert.ok(done, `subtitles never processed: ${JSON.stringify(await readStatus(page))}`);
  await until(async () => (await readStatus(page)).every(s => !s.endsWith(':failed')), { timeout: 10000 });
  assert.deepEqual(await readStatus(page), ['SRT:srt:converted', 'ASS:ass:converted', 'TTML:ttml:converted']);
  const labels = await page.evaluate(() => window._shakaPlayer.getTextTracks().map(t => t.label));
  assert.deepEqual(labels, ['SRT', 'ASS', 'TTML']);
  // The first track is shown. Shaka UI draws cues in its own container for HLS/DASH; for a plain
  // file (src= mode, as here) it keeps the browser's native text track. Accept either.
  const cue = await until(() => page.evaluate(() => {
    const box = document.querySelector('.shaka-text-container');
    if (box && box.textContent.trim()) return box.textContent.trim();
    for (const tt of document.getElementById('video').textTracks) {
      if (tt.mode === 'showing' && tt.cues && tt.cues.length) return tt.cues[0].text;
    }
    return null;
  }), { timeout: 10000 });
  assert.equal(cue, 'Café “quoted”');
  // only the selected track is drawn (src= mode used to show every track at once)
  const drawn = await page.evaluate(() => [...document.getElementById('video').textTracks].filter(t => t.mode !== 'disabled').map(t => t.label));
  assert.deepEqual(drawn, ['SRT']);
  await page.close();
});

// Firefox regression: Shaka attached before its UI existed fell back to the browser's native
// cues for HLS/DASH, which Firefox draws ~10 px high. Shaka must draw them itself, sized to the window.
test('Shaka page: HLS subtitles are drawn by Shaka UI, sized to the window', async () => {
  const page = await ctx.newPage();
  const subs = encodeURIComponent(JSON.stringify([{ url: `${ORIGIN}/subs/long.srt`, label: 'English', lang: 'en' }]));
  await page.goto(`chrome-extension://${extId}/player-shaka.html?url=${encodeURIComponent(`${ORIGIN}/hls-real/index.m3u8`)}&subs=${subs}`);
  const font = await until(() => page.evaluate(() => {
    const span = [...document.querySelectorAll('.shaka-text-container span')].find(s => /ordinary length/.test(s.textContent) && !s.querySelector('span'));
    return span ? parseFloat(getComputedStyle(span).fontSize) : null;
  }), { timeout: 15000 });
  assert.ok(font, 'cue not drawn in .shaka-text-container');
  const showing = await page.evaluate(() => [...document.getElementById('video').textTracks].filter(t => t.mode === 'showing').length);
  assert.equal(showing, 0, 'a native text track is showing too');
  const vmin = await page.evaluate(() => Math.min(innerWidth, innerHeight));
  assert.ok(font >= vmin * 0.04, `subtitle font ${font}px for a ${vmin}px window`);
  await page.close();
});

test('ArtPlayer page: subtitles are sized to the window, and "Subtitle size" scales them', async () => {
  const page = await ctx.newPage();
  const subs = encodeURIComponent(JSON.stringify([{ url: `${ORIGIN}/subs/long.srt`, label: 'English', lang: 'en' }]));
  await page.goto(`chrome-extension://${extId}/player-art.html?url=${encodeURIComponent(`${ORIGIN}/hls-real/index.m3u8`)}&subs=${subs}`);
  const fontOf = () => page.evaluate(() => {
    const el = [...document.querySelectorAll('.art-subtitle *')].find(e => /ordinary length/.test(e.textContent) && !e.children.length);
    return el && el.getBoundingClientRect().height ? parseFloat(getComputedStyle(el).fontSize) : null;
  });
  const font = await until(fontOf, { timeout: 15000 });
  assert.ok(font, 'cue not drawn');
  const vmin = await page.evaluate(() => Math.min(innerWidth, innerHeight));
  assert.ok(font >= vmin * 0.04, `subtitle font ${font}px for a ${vmin}px window`);
  // the size setting multiplies the base size (as "Large" does)
  await page.evaluate(() => window._art.subtitle.style({ fontSize: 'calc(var(--art-subtitle-font-size, 20px) * 1.3)' }));
  const large = await until(async () => { const f = await fontOf(); return f && f > font * 1.2 ? f : null; }, { timeout: 3000 });
  assert.ok(large, `size setting did not scale the subtitles (${font}px)`);
  await page.close();
});

test('ArtPlayer page: SRT (cp1252), ASS and TTML subtitles converted, drawn with italics kept, "c" cycles them', async () => {
  const page = await ctx.newPage();
  await page.goto(`chrome-extension://${extId}/player-art.html?${subsQuery()}`);
  const done = await until(async () => { const s = await readStatus(page); return s.length === 3 && !s.some(x => x.endsWith(':pending')); }, { timeout: 20000 });
  assert.ok(done, `subtitles never processed: ${JSON.stringify(await readStatus(page))}`);
  assert.deepEqual(await readStatus(page), ['SRT:srt:converted', 'ASS:ass:converted', 'TTML:ttml:converted']);
  await until(() => page.evaluate(() => window._subtitleSelected === 'SRT'));
  const shown = async () => page.evaluate(() => (document.querySelector('.art-subtitle') || {}).innerHTML || '');
  const atStart = () => page.evaluate(async () => { const v = document.querySelector('video'); v.pause(); v.currentTime = 1; await new Promise(r => setTimeout(r, 400)); });
  await atStart();
  assert.match(await until(async () => { const h = await shown(); return h.includes('Café') ? h : null; }) || '', /Café “quoted”/);
  await page.keyboard.press('c');
  await until(() => page.evaluate(() => window._subtitleSelected === 'ASS'));
  await atStart();
  const ass = await until(async () => { const h = await shown(); return h.includes('Styled') ? h : null; });
  assert.match(ass || '', /<i>Styled<\/i> line, with comma/);
  await page.keyboard.press('c');
  await page.keyboard.press('c');
  await until(() => page.evaluate(() => window._subtitleSelected === null));
  await atStart();
  // off: the subtitle layer is hidden
  assert.equal(await page.evaluate(() => { const el = document.querySelector('.art-subtitle'); return !el || el.offsetHeight === 0 || getComputedStyle(el).display === 'none' || getComputedStyle(el).visibility === 'hidden'; }), true);
  // the settings panel lists them (with "Off") and a subtitle size
  const names = await page.$$eval('.art-setting-item', els => els.map(e => e.dataset.name).filter(Boolean));
  assert.ok(names.includes('sap-subtitles') && names.includes('sap-subtitle-size'), `settings: ${names}`);
  await page.close();
});

// ── header forwarding ────────────────────────────────────────────────────────

test('captures the page Referer / User-Agent on the stream', async () => {
  const page = await openSite('/p/secure');
  await until(async () => (await readItems(page)).length === 1);
  const tabId = await tabIdOf(page);
  const stream = await sw.evaluate(async id => ((await chrome.storage.local.get('detectedStreams')).detectedStreams.find(e => e[0] === id) || [0, []])[1][0], tabId);
  assert.equal(stream.headers.referer, `${ORIGIN}/p/secure`);
  assert.ok(stream.headers.userAgent.length > 10);
  await page.close();
});

test('duration of a playlist that needs the page Referer (analysis request carries it)', async () => {
  site.log.secureReferers.length = 0;
  const page = await openSite('/p/secure');
  const items = await until(async () => { const r = await readItems(page); return r.length === 1 && r[0].duration ? r : null; });
  assert.ok(items, `no duration: ${JSON.stringify(await readItems(page))} referers ${JSON.stringify(site.log.secureReferers)}`);
  assert.equal(items[0].duration, '0:05');
  // the page's request and the background's, both with the page as Referer; the rule is gone after
  assert.ok(site.log.secureReferers.length >= 2 && site.log.secureReferers.every(r => r === `${ORIGIN}/p/secure`), JSON.stringify(site.log.secureReferers));
  const left = await sw.evaluate(async () => (await chrome.declarativeNetRequest.getSessionRules()).filter(r => r.id >= 1900000000).length);
  assert.equal(left, 0);
  await page.close();
});

test('built-in web player sends the page Referer to the CDN (declarativeNetRequest rule)', async () => {
  await setSettings({ webPlayerEngine: 'shaka' });
  site.log.secureReferers.length = 0;
  const page = await openSite('/p/secure');
  await until(async () => (await readItems(page)).length === 1);
  site.log.secureReferers.length = 0; // forget the page's own request
  await page.click('#video-handler-button');
  const [player] = await Promise.all([ctx.waitForEvent('page'), page.click('.v-action-play')]);
  await until(() => site.log.secureReferers.length > 0, { timeout: 15000 });
  assert.ok(site.log.secureReferers.length > 0, 'player never requested the playlist');
  assert.equal(site.log.secureReferers[0], `${ORIGIN}/p/secure`, 'Referer was not rewritten');
  await player.close();
  await page.close();
});

test('native launch command carries referrer, user agent, title (mpv preset) and subtitles', async () => {
  await setSettings({ externalPlayerPath: 'C:\\Tools\\mpv.exe', nativeArgsTemplate: '' });
  const page = await openSite('/p/subs');
  await until(async () => (await readItems(page)).length && (await page.$('.sub-badge')));
  const tabId = await tabIdOf(page);
  const cmd = await sw.evaluate(async (id) => buildNativeCommand(await buildContext(id, 'http://localhost:8099/media/clip_720p.mp4', 'http://localhost:8099/media/clip_720p.mp4')), tabId);
  assert.equal(cmd[0], 'C:\\Tools\\mpv.exe');
  assert.ok(cmd.includes(`--referrer=${ORIGIN}/p/subs`), JSON.stringify(cmd));
  assert.ok(cmd.some(a => a.startsWith('--user-agent=')));
  assert.ok(cmd.includes('--force-media-title=Subs'));
  assert.equal(cmd.filter(a => a.startsWith('--sub-file=')).length, 2);
  assert.ok(!cmd.some(a => a.includes('Cookie')), 'cookies must not be forwarded by default');
  assert.equal(cmd[cmd.length - 1], 'http://localhost:8099/media/clip_720p.mp4');

  await setSettings({ externalPlayerPath: 'C:\\Tools\\vlc.exe' });
  const vlc = await sw.evaluate(async (id) => buildNativeCommand(await buildContext(id, 'http://x/y.mp4', 'http://x/y.mp4')), tabId);
  assert.ok(vlc.includes(`--http-referrer=${ORIGIN}/p/subs`), JSON.stringify(vlc));

  await setSettings({ nativeArgsTemplate: '--custom "{title}" {url}' });
  const real = 'http://localhost:8099/media/clip_720p.mp4';
  const custom = await sw.evaluate(async ([id, u]) => buildNativeCommand(await buildContext(id, u, u)), [tabId, real]);
  assert.deepEqual(custom.slice(1), ['--custom', 'Subs', real]);
  await setSettings({ externalPlayerPath: '', nativeArgsTemplate: '' });
  await page.close();
});

// ── players ──────────────────────────────────────────────────────────────────

test('DASH streams are routed to the Shaka page (button and direct Vidstack link)', async () => {
  await setSettings({ webPlayerEngine: 'vidstack' });
  const page = await openSite('/p/dash');
  await until(async () => (await readItems(page)).length === 1);
  await page.click('#video-handler-button');
  const [player] = await Promise.all([ctx.waitForEvent('page'), page.click('.v-action-play')]);
  await until(() => player.url().includes('player-shaka.html'));
  assert.match(player.url(), /player-shaka\.html/);
  await player.close();

  const direct = await ctx.newPage();
  await direct.goto(`chrome-extension://${extId}/player.html?url=${encodeURIComponent('http://example.com/a.mpd')}`);
  await until(() => direct.url().includes('player-shaka.html'));
  assert.match(direct.url(), /player-shaka\.html\?url=/);
  await direct.close();
  await page.close();
});

test('ArtPlayer engine: HLS and DASH streams open in the ArtPlayer page and play', async () => {
  await setSettings({ webPlayerEngine: 'artplayer' });
  for (const [route, isDash] of [['/p/dash-real', true], ['/p/subs', false]]) {
    const page = await openSite(route);
    await until(async () => (await readItems(page)).length >= 1, { timeout: 15000 });
    await page.click('#video-handler-button');
    const [player] = await Promise.all([ctx.waitForEvent('page'), page.click('.v-action-play')]);
    await until(() => player.url().includes('player-art.html'));
    assert.match(player.url(), /player-art\.html\?url=/);
    if (isDash) {
      const playing = await until(() => player.evaluate(() => { const v = document.querySelector('video'); return v && v.currentTime > 0.3 && v.videoWidth > 0; }), { timeout: 20000 });
      assert.ok(playing, 'DASH did not play in ArtPlayer');
    }
    await player.close();
    await page.close();
  }
  await setSettings({ webPlayerEngine: 'vidstack' });
});

test('popup lists the streams of a tab', async () => {
  const page = await openSite('/p/master');
  await until(async () => { const r = await readItems(page); return r.length && r[0].variants.length; });
  const tabId = await tabIdOf(page);
  const popup = await ctx.newPage();
  await popup.goto(`chrome-extension://${extId}/popup.html?tabId=${tabId}`);
  await popup.waitForSelector('.stream-row');
  assert.equal(await popup.locator('.stream-row').count(), 1);
  assert.equal(await popup.locator('.stream-row .badge.quality').textContent(), '1080p');
  assert.equal(await popup.locator('.stream-row select option').count(), 4);
  await popup.click('.row-btn[title="Copy URL"]');
  await sleep(300);
  assert.match(await popup.evaluate(() => navigator.clipboard.readText()), /master\.m3u8$/);
  await popup.close();
  await page.close();
});

test('selecting a quality variant changes the URL that is copied', async () => {
  const page = await openSite('/p/master');
  await until(async () => { const r = await readItems(page); return r.length && r[0].variants.length; });
  await page.click('#video-handler-button');
  await page.selectOption('.v-quality', { label: '720p' });
  await page.click('.v-action-copy');
  await sleep(300);
  assert.match(await page.evaluate(() => navigator.clipboard.readText()), /v720\/index\.m3u8$/);
  await page.close();
});

// ── phase 1: detection signals, patterns, titles ────────────────────────────

const readSubtitles = page => page.$$eval('.stream-item .stream-subtitle', els => els.map(e => e.textContent));

test('error responses are not listed as streams', async () => {
  const page = await openSite('/p/missing', { settle: 3000 });
  assert.equal((await readItems(page)).length, 0);
  await page.close();
});

test('a stream URL carried in a .php query string is detected', async () => {
  const page = await openSite('/p/proxied');
  const items = await until(async () => { const r = await readItems(page); return r.length ? r : null; });
  assert.ok(items, 'proxied stream not detected');
  assert.match(items[0].url, /proxy\.php\?u=/);
  assert.match(items[0].name, /\(m3u8\)/);
  await page.close();
});

test('"media" requests are detected without a stream-like URL or content type', async () => {
  const page = await openSite('/p/media');
  const items = await until(async () => { const r = await readItems(page); return r.length ? r : null; });
  assert.ok(items, 'media request not detected');
  assert.match(items[0].url, /\/get\?id=7$/);
  await page.close();
});

test('custom detection patterns make an unrecognised URL a stream (and the popup validates them)', async () => {
  let page = await openSite('/p/custom', { settle: 2500 });
  assert.equal((await readItems(page)).length, 0, 'detected without the pattern');
  await page.close();

  await setSettings({ customPatterns: 'm3u8 /\\/api\\/play\\/\\d+/' });
  page = await openSite('/p/custom');
  const items = await until(async () => { const r = await readItems(page); return r.length ? r : null; });
  assert.ok(items, 'pattern did not match');
  assert.match(items[0].name, /\(m3u8\)/);
  await page.close();

  // popup: live validation and saving
  const popup = await ctx.newPage();
  await popup.goto(`chrome-extension://${extId}/popup.html`);
  assert.ok(await until(async () => /api/.test(await popup.inputValue('#custom-patterns'))), 'saved patterns not shown');
  // the status line is filled once the popup has finished starting
  await until(async () => /OK/.test(await popup.textContent('#custom-patterns-status')));
  await popup.click('#tab-filters');
  await popup.fill('#custom-patterns', 'm3u8 /ok/\nbogus /x/\nvideo /([/');
  const status = await popup.textContent('#custom-patterns-status');
  assert.match(status, /Line 2: Unknown type/);
  assert.match(status, /Line 3: Invalid regular expression/);
  await popup.fill('#custom-patterns', 'video /\\/get_file\\//');
  await popup.fill('#blacklist', 'ads.com\n~([');
  assert.match(await popup.textContent('#domain-list-error'), /not a valid rule/);
  await popup.click('#save-lists');
  await sleep(400);
  const saved = await sw.evaluate(async () => (await chrome.storage.local.get('settings')).settings);
  assert.equal(saved.customPatterns, 'video /\\/get_file\\//');
  assert.deepEqual(saved.blacklist, ['ads.com', '~([']);
  await popup.close();
  await setSettings({ customPatterns: '', blacklist: [] });
});

test('page titles are cleaned for the list, and updated when the title changes later', async () => {
  let page = await openSite('/p/titled');
  await until(async () => (await readSubtitles(page)).length > 0);
  assert.deepEqual(await readSubtitles(page), ['Dark Matter S01E05']);
  await page.close();

  page = await openSite('/p/late-title');
  await until(async () => (await readItems(page)).length === 1);
  const better = await until(async () => (await readSubtitles(page))[0] === 'Big Buck Bunny (2008)', { timeout: 8000 });
  assert.ok(better, `title never refreshed: ${JSON.stringify(await readSubtitles(page))}`);
  await page.close();
});

test('whitelist/blacklist use whole-label matching', async () => {
  await setSettings({ blacklist: ['host'] }); // "localhost" must not match the label "host"
  let page = await openSite('/p/video');
  assert.equal((await until(async () => { const r = await readItems(page); return r.length ? r : null; }) || []).length, 1);
  await page.close();

  await setSettings({ blacklist: ['example.com', '-localhost'] });
  page = await openSite('/p/video', { settle: 3000 });
  assert.equal((await readItems(page)).length, 0, 'exact rule did not block localhost');
  await page.close();

  await setSettings({ blacklist: ['localhost', '!localhost'] });
  page = await openSite('/p/video');
  assert.equal((await until(async () => { const r = await readItems(page); return r.length ? r : null; }) || []).length, 1, 'exception ignored');
  await page.close();
  await setSettings({ blacklist: [] });
});

// ── phase 3: direct stream links open in the web player ──────────────────────

// Navigates a fresh tab to `url` and returns where it ended up (redirects to extension pages
// abort Playwright's own navigation bookkeeping, so the URL is polled instead).
async function landOn(url, expect) {
  const page = await ctx.newPage();
  await page.goto(url, { waitUntil: 'commit' }).catch(() => {});
  if (expect) await until(() => expect.test(page.url()), { timeout: 8000 });
  else await sleep(2000);
  return page;
}

test('direct .m3u8 / .mpd links open in the web player when enabled (and only then)', async () => {
  await setSettings({ openStreamLinks: false, openMp4Links: false, webPlayerEngine: 'vidstack' });
  let page = await landOn(`${ORIGIN}/hls/early.m3u8`);
  assert.equal(page.url(), `${ORIGIN}/hls/early.m3u8`, 'redirected while the option is off');
  await page.close();

  await setSettings({ openStreamLinks: true });
  await sleep(500); // dynamic rules are updated asynchronously
  page = await landOn(`${ORIGIN}/hls/early.m3u8?t=1`, /player\.html/);
  assert.equal(page.url(), `chrome-extension://${extId}/player.html#${ORIGIN}/hls/early.m3u8?t=1`);
  // the page really took the URL from its fragment
  const src = await until(() => page.evaluate(() => document.querySelector('media-player').src || null));
  assert.match(JSON.stringify(src), /hls\/early\.m3u8\?t=1/);
  await page.close();

  page = await landOn(`${ORIGIN}/dash/manifest.mpd`, /player-shaka\.html/);
  assert.equal(page.url(), `chrome-extension://${extId}/player-shaka.html#${ORIGIN}/dash/manifest.mpd`);
  await page.close();

  // a page that merely mentions a stream in its query string is left alone
  page = await landOn(`${ORIGIN}/p/blank?next=a.m3u8`);
  assert.equal(page.url(), `${ORIGIN}/p/blank?next=a.m3u8`);
  await page.close();

  // .mp4 only with its own option; then with the Shaka engine
  page = await landOn(`${ORIGIN}/media/clip_720p.mp4`);
  assert.equal(page.url(), `${ORIGIN}/media/clip_720p.mp4`, '.mp4 redirected without its option');
  await page.close();
  await setSettings({ openMp4Links: true, webPlayerEngine: 'shaka' });
  await sleep(500);
  page = await landOn(`${ORIGIN}/media/clip_720p.mp4`, /player-shaka\.html/);
  assert.match(page.url(), /player-shaka\.html#http:\/\/localhost:8099\/media\/clip_720p\.mp4$/);
  await page.close();

  await setSettings({ openStreamLinks: false, openMp4Links: false, webPlayerEngine: 'vidstack' });
  await sleep(500);
  const left = await sw.evaluate(async () => (await chrome.declarativeNetRequest.getDynamicRules()).map(r => r.id));
  assert.deepEqual(left, []);
});

// ── phase 4: frames, service workers, header rules ──────────────────────────

const streamsOf = tabId => sw.evaluate(async id => ((await chrome.storage.local.get('detectedStreams')).detectedStreams || []).find(e => e[0] === id)?.[1] || [], tabId);

test('a stream inside a cross-origin iframe is found, with the iframe as Referer', async () => {
  const page = await openSite('/p/iframe');
  const tabId = await tabIdOf(page);
  const found = await until(async () => (await streamsOf(tabId)).find(s => s.url.endsWith('/hls/frame.m3u8')), { timeout: 12000 });
  assert.ok(found, 'iframe stream not detected');
  assert.equal(found.headers.referer, 'http://127.0.0.1:8099/p/inner');
  await page.close();
});

test('a playlist fetched by the page\'s service worker is attributed to the tab', async () => {
  const page = await openSite('/p/sw');
  const items = await until(async () => { const r = await readItems(page); return r.find(i => /sw\.m3u8/.test(i.url)) ? r : null; }, { timeout: 12000 });
  assert.ok(items, 'service-worker request not detected');
  await page.evaluate(async () => { for (const r of await navigator.serviceWorker.getRegistrations()) await r.unregister(); });
  await page.close();
});

test('player header rule: cookies forwarded when enabled, rule removed when the tab leaves the player', async () => {
  await setSettings({ webPlayerEngine: 'shaka', forwardCookies: true });
  site.log.cookies.length = 0;
  const page = await openSite('/p/cookie');
  await until(async () => (await readItems(page)).length === 1);
  site.log.cookies.length = 0; // forget the page's own request
  await page.click('#video-handler-button');
  const [player] = await Promise.all([ctx.waitForEvent('page'), page.click('.v-action-play')]);
  await until(() => site.log.cookies.length > 0, { timeout: 15000 });
  assert.ok(site.log.cookies.length > 0, 'player never requested the playlist');
  assert.match(site.log.cookies[0] || '', /sap=yes/, 'Cookie was not forwarded to the player request');

  await until(() => player.url().includes('player-shaka.html'));
  const playerTab = await sw.evaluate(async (u) => (await chrome.tabs.query({})).find(t => t.url === u).id, player.url());
  const ruleIds = () => sw.evaluate(async () => (await chrome.declarativeNetRequest.getSessionRules()).map(r => r.id));
  assert.ok((await ruleIds()).includes(playerTab + 1), 'no header rule while the player is open');
  await player.goto(`${ORIGIN}/p/blank`);
  assert.ok(await until(async () => !(await ruleIds()).includes(playerTab + 1)), 'rule survived navigating away');
  await player.close();
  await page.close();
  await setSettings({ forwardCookies: false });
});

// ── phase 6: faster buffering (parallel segment downloads) ──────────────────

// Highest number of segment requests that were in flight at the same moment
function maxConcurrent(segments) {
  const events = [];
  for (const s of segments) { events.push([s.start, 1]); events.push([s.end || Infinity, -1]); }
  events.sort((a, b) => a[0] - b[0] || a[1] - b[1]);
  let cur = 0;
  let max = 0;
  for (const [, d] of events) { cur += d; max = Math.max(max, cur); }
  return max;
}

// Opens a player on the throttled HLS fixture and measures how long 20 s of video take to buffer
async function bufferRun(file, enabled) {
  // the prefetcher path (with the whole-video download off)
  await setSettings({ fastBuffering: enabled, fastBufferingParallel: 4, bufferAheadSeconds: 60, cacheWholeVideo: false });
  site.log.segments.length = 0;
  const page = await ctx.newPage();
  const t0 = Date.now();
  await page.goto(`chrome-extension://${extId}/${file}?url=${encodeURIComponent(`${ORIGIN}/slow-hls/index.m3u8`)}`);
  const ok = await until(() => page.evaluate(() => {
    const v = document.querySelector('video');
    return v && v.buffered.length && v.buffered.end(v.buffered.length - 1) >= 20;
  }), { timeout: 30000 });
  const ms = Date.now() - t0;
  const playable = await page.evaluate(() => document.querySelector('video').readyState >= 3);
  const info = { ms, conc: maxConcurrent(site.log.segments), playable, prefetch: await page.evaluate(() => window._prefetch ? window._prefetch.stats : null) };
  await page.close();
  assert.ok(ok, `${file} never buffered 20 s (${JSON.stringify(info)})`);
  return info;
}

test('faster buffering: Vidstack/hls.js loads segments in parallel and buffers sooner on a slow CDN', async (t) => {
  const off = await bufferRun('player.html', false);
  const on = await bufferRun('player.html', true);
  t.diagnostic(`vidstack off: ${off.ms} ms, ${off.conc} at once; on: ${on.ms} ms, ${on.conc} at once, hits ${on.prefetch && on.prefetch.hits}`);
  assert.equal(off.conc, 1, `hls.js alone should load one segment at a time: ${JSON.stringify(off)}`);
  assert.ok(on.conc >= 2, `no parallel downloads: ${JSON.stringify(on)}`);
  assert.ok(on.playable && off.playable, 'video not playable');
  assert.ok(on.prefetch && on.prefetch.hits > 0, `player never used a prefetched segment: ${JSON.stringify(on.prefetch)}`);
  assert.ok(on.ms < off.ms * 0.75, `not faster: on ${on.ms} ms vs off ${off.ms} ms`);
});

test('faster buffering: ArtPlayer/hls.js loads segments in parallel and buffers sooner', async (t) => {
  const off = await bufferRun('player-art.html', false);
  const on = await bufferRun('player-art.html', true);
  t.diagnostic(`artplayer off: ${off.ms} ms, ${off.conc} at once; on: ${on.ms} ms, ${on.conc} at once`);
  assert.ok(on.conc >= 2, `no parallel downloads: ${JSON.stringify(on)}`);
  assert.ok(on.prefetch && on.prefetch.hits > 0, `player never used a prefetched segment: ${JSON.stringify(on.prefetch)}`);
  assert.ok(on.ms < off.ms, `not faster: on ${on.ms} ms vs off ${off.ms} ms`);
});

test('faster buffering: Shaka prefetches segments in parallel', async (t) => {
  const off = await bufferRun('player-shaka.html', false);
  const on = await bufferRun('player-shaka.html', true);
  t.diagnostic(`shaka off: ${off.ms} ms, ${off.conc} at once; on: ${on.ms} ms, ${on.conc} at once`);
  assert.ok(on.conc > off.conc, `no extra parallelism: on ${on.conc}, off ${off.conc}`);
  assert.ok(on.playable, 'video not playable');
  assert.ok(on.ms < off.ms, `not faster: on ${on.ms} ms vs off ${off.ms} ms`);
  await setSettings({ fastBuffering: true, bufferAheadSeconds: 0, cacheWholeVideo: true });
});

// ── phase 7: download to MP4 in the browser ──────────────────────────────────

const boxTypes = buf => {
  const out = [];
  for (let p = 0; p + 8 <= buf.length;) {
    const size = buf.readUInt32BE(p);
    out.push(buf.toString('latin1', p + 4, p + 8));
    if (size < 8) break;
    p += size;
  }
  return out;
};

// Opens download.html for `mediaUrl`, presses Download, returns { state, file (Buffer), name }
async function downloadVia(mediaUrl, title = 'Test Clip', extra = '') {
  const page = await ctx.newPage();
  await page.goto(`chrome-extension://${extId}/download.html?url=${encodeURIComponent(mediaUrl)}&title=${encodeURIComponent(title)}${extra}`);
  const ready = await until(() => page.evaluate(() => window._download && ['ready', 'error'].includes(window._download.state) && window._download), { timeout: 20000 });
  assert.equal(ready && ready.state, 'ready', `not ready: ${JSON.stringify(ready)}`);
  const [download] = await Promise.all([page.waitForEvent('download', { timeout: 30000 }), page.click('#start')]);
  const file = path.join(os.tmpdir(), `sap-dl-${Date.now()}-${download.suggestedFilename()}`);
  await download.saveAs(file);
  const state = await page.evaluate(() => window._download);
  const data = fs.readFileSync(file);
  fs.rmSync(file, { force: true });
  await page.close();
  return { state, data, name: download.suggestedFilename() };
}

// Plays a downloaded file in a normal web page: duration, a seek, decoded audio
async function probeMedia(data, type) {
  const page = await ctx.newPage();
  await page.goto(`${ORIGIN}/p/blank`);
  return await page.evaluate(async ({ b64, type }) => {
    const bytes = Uint8Array.from(atob(b64), c => c.charCodeAt(0));
    const v = document.createElement('video');
    v.muted = true;
    v.src = URL.createObjectURL(new Blob([bytes], { type }));
    document.body.appendChild(v);
    await new Promise((ok, bad) => { v.onloadedmetadata = ok; v.onerror = () => bad(new Error('media error ' + (v.error && v.error.code))); });
    const duration = v.duration;
    v.currentTime = 15;
    await new Promise(r => { v.onseeked = r; setTimeout(r, 5000); });
    const seekedTo = v.currentTime;
    v.currentTime = 0;
    await v.play().catch(() => {});
    await new Promise(r => setTimeout(r, 1500));
    v.pause();
    return { duration, seekedTo, audioBytes: v.webkitAudioDecodedByteCount || 0, videoBytes: v.webkitVideoDecodedByteCount || 0 };
  }, { b64: data.toString('base64'), type }).finally(() => page.close());
}

test('download: fMP4 HLS becomes one seekable MP4 (ftyp, moov, sidx, fragments)', async () => {
  const { state, data, name } = await downloadVia(`${ORIGIN}/hls-real/index.m3u8`, 'Test Clip S01E02');
  assert.equal(state.state, 'done', JSON.stringify(state));
  assert.equal(name, 'Test Clip S01E02.mp4');
  assert.deepEqual(boxTypes(data).slice(0, 3), ['ftyp', 'moov', 'sidx']);
  assert.equal(boxTypes(data).filter(t => t === 'moof').length, 12);
  assert.deepEqual(state.tracks.map(t => t.handler), ['vide']);
  const media = await probeMedia(data, 'video/mp4');
  assert.ok(Math.abs(media.duration - 24) < 1.5, `duration ${media.duration}`);
  assert.ok(Math.abs(media.seekedTo - 15) < 1, `seek landed at ${media.seekedTo}`);
  assert.ok(media.videoBytes > 0, 'no video decoded');
});

test('download: "Save again" asks once more before writing another copy', async () => {
  const page = await ctx.newPage();
  await page.goto(`chrome-extension://${extId}/download.html?url=${encodeURIComponent(`${ORIGIN}/hls-real/index.m3u8`)}&title=Again`);
  await until(() => page.evaluate(() => window._download && window._download.state === 'ready'), { timeout: 20000 });
  const downloads = [];
  page.on('download', d => { downloads.push(d); d.cancel().catch(() => {}); });
  await page.click('#start');
  await until(() => page.evaluate(() => window._download.state === 'done'), { timeout: 30000 });
  await until(() => downloads.length === 1, { timeout: 10000 });
  await page.click('#again');
  await page.waitForTimeout(500);
  assert.equal(downloads.length, 1, 'the first tap saved another copy');
  assert.match(await page.textContent('#again'), /Save another copy/);
  assert.match(await page.textContent('#warning'), /Another copy needs/);
  await page.click('#again');
  await until(() => downloads.length === 2, { timeout: 10000 });
  assert.equal(await page.evaluate(() => window._download.saves), 2);
  assert.equal(await page.textContent('#again'), 'Save again');
  await page.close();
});

test('download: separate audio rendition is merged into the same MP4 (and plays)', async () => {
  const { state, data } = await downloadVia(`${ORIGIN}/hls-real/master.m3u8`);
  assert.equal(state.state, 'done', JSON.stringify(state));
  assert.deepEqual(state.tracks.map(t => t.handler).sort(), ['soun', 'vide']);
  const media = await probeMedia(data, 'video/mp4');
  assert.ok(Math.abs(media.duration - 24) < 1.5, `duration ${media.duration}`);
  assert.ok(media.audioBytes > 0, 'audio was not decoded');
  assert.ok(media.videoBytes > 0, 'video was not decoded');
});

// Text samples of the tx3g tracks of an MP4: { trackId: [texts in file order] }
function tx3gTexts(buf) {
  const boxes = (start, end) => {
    const out = [];
    for (let p = start; p + 8 <= end;) {
      const size = buf.readUInt32BE(p);
      if (size < 8) break;
      out.push({ type: buf.toString('latin1', p + 4, p + 8), start: p, end: p + size, body: p + 8 });
      p += size;
    }
    return out;
  };
  const top = boxes(0, buf.length);
  const moov = top.find(b => b.type === 'moov');
  const textIds = boxes(moov.body, moov.end).filter(b => b.type === 'trak').filter(t => {
    const mdia = boxes(t.body, t.end).find(b => b.type === 'mdia');
    const hdlr = boxes(mdia.body, mdia.end).find(b => b.type === 'hdlr');
    return buf.toString('latin1', hdlr.body + 8, hdlr.body + 12) === 'sbtl';
  }).map(t => buf.readUInt32BE(boxes(t.body, t.end).find(b => b.type === 'tkhd').body + 12));
  const texts = Object.fromEntries(textIds.map(id => [id, []]));
  for (let i = 0; i < top.length; i++) {
    if (top[i].type !== 'moof') continue;
    const traf = boxes(top[i].body, top[i].end).find(b => b.type === 'traf');
    const tfhd = boxes(traf.body, traf.end).find(b => b.type === 'tfhd');
    const id = buf.readUInt32BE(tfhd.body + 4);
    if (!texts[id]) continue;
    const trun = boxes(traf.body, traf.end).find(b => b.type === 'trun');
    const count = buf.readUInt32BE(trun.body + 4);
    let p = top[i].start + buf.readInt32BE(trun.body + 8);
    for (let k = 0; k < count; k++) {
      const size = buf.readUInt32BE(trun.body + 12 + k * 8 + 4);
      const len = buf.readUInt16BE(p);
      if (len) texts[id].push(buf.toString('utf8', p + 2, p + 2 + len));
      p += size;
    }
  }
  return texts;
}

test('download: subtitles go into the MP4 as text tracks (page files + manifest track) and as .srt', async () => {
  const subs = JSON.stringify([{ url: `${ORIGIN}/subs/fr.srt`, label: 'French', lang: 'fr' }, { url: `${ORIGIN}/subs/cp1252.srt`, label: 'Old SRT', lang: '' }]);
  const page = await ctx.newPage();
  await page.goto(`chrome-extension://${extId}/download.html?url=${encodeURIComponent(`${ORIGIN}/hls-subs/master.m3u8`)}&title=Subbed&subs=${encodeURIComponent(subs)}`);
  const ready = await until(() => page.evaluate(() => window._download && ['ready', 'error'].includes(window._download.state) && window._download), { timeout: 20000 });
  assert.equal(ready.state, 'ready', JSON.stringify(ready));
  assert.deepEqual(ready.subtitleChoices.map(c => [c.source, c.label, c.language]),
    [['manifest', 'Deutsch', 'de'], ['file', 'French', 'fr'], ['file', 'Old SRT', 'und']]);
  assert.equal(await page.isVisible('#subs-field'), true);
  await page.check('#subs-files');
  const downloads = [];
  page.on('download', d => downloads.push(d));
  await page.click('#start');
  const done = await until(() => page.evaluate(() => ['done', 'error'].includes(window._download.state) && window._download), { timeout: 30000 });
  assert.equal(done.state, 'done', JSON.stringify(done));
  await until(() => downloads.length >= 4, { timeout: 10000 });
  const names = downloads.map(d => d.suggestedFilename());
  assert.deepEqual(names, ['Subbed.mp4', 'Subbed.de.srt', 'Subbed.fr.srt', 'Subbed.Old_SRT.srt']);
  const read = async d => { const f = path.join(os.tmpdir(), `sap-dl-${Date.now()}-${d.suggestedFilename()}`); await d.saveAs(f); const b = fs.readFileSync(f); fs.rmSync(f, { force: true }); return b; };
  const mp4 = await read(downloads[0]);
  assert.deepEqual(done.tracks.map(t => t.handler), ['vide', 'sbtl', 'sbtl', 'sbtl']);
  assert.deepEqual(done.subtitles.map(t => [t.label, t.cues, t.base]), [['Deutsch', 3, 'media'], ['French', 1, 'output'], ['Old SRT', 1, 'output']]);
  const texts = Object.values(tx3gTexts(mp4)).map(list => [...new Set(list)]);
  assert.deepEqual(texts, [['Guten Tag', 'Über die Grenze', 'Auf Wiedersehen'], ['Bonjour'], ['Café “quoted”']]);
  const srt = (await read(downloads[1])).toString('utf8');
  assert.match(srt, /00:00:01,000 --> 00:00:03,000\r?\nGuten Tag/);
  assert.match(srt, /00:00:11,000 --> 00:00:13,000\r?\n\u00dcber die Grenze\r?\n\r?\n3\r?\n/);
  // the video still plays
  const media = await probeMedia(mp4, 'video/mp4');
  assert.ok(Math.abs(media.duration - 24) < 1.5, `duration ${media.duration}`);
  assert.ok(media.videoBytes > 0, 'no video decoded');
  await page.close();
});

test('download: AES-128 encrypted HLS is decrypted', async () => {
  const { state, data } = await downloadVia(`${ORIGIN}/hls-real/enc.m3u8`);
  assert.equal(state.state, 'done', JSON.stringify(state));
  const media = await probeMedia(data, 'video/mp4');
  assert.ok(Math.abs(media.duration - 24) < 1.5, `duration ${media.duration}`);
  assert.ok(media.videoBytes > 0, 'decrypted video did not decode');
});

test('download: MPEG-TS HLS with muxed audio is transmuxed into one MP4 (network)', { skip: !NETWORK && 'set E2E_NETWORK=1', timeout: 300000 }, async () => {
  const page = await ctx.newPage();
  await page.goto(`chrome-extension://${extId}/download.html?url=${encodeURIComponent('https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8')}&title=BBB`);
  assert.ok(await until(() => page.evaluate(() => window._download && window._download.state === 'ready'), { timeout: 30000 }), 'not ready');
  // lowest quality keeps the download small
  const values = await page.$$eval('#quality option', os => os.map(o => o.value));
  await page.selectOption('#quality', values[values.length - 1]);
  const [download] = await Promise.all([page.waitForEvent('download', { timeout: 280000 }), page.click('#start')]);
  const file = path.join(os.tmpdir(), `sap-ts-${Date.now()}.mp4`);
  await download.saveAs(file);
  const state = await page.evaluate(() => window._download);
  await page.close();
  const data = fs.readFileSync(file);
  fs.rmSync(file, { force: true });
  assert.deepEqual(state.tracks.map(t => t.handler).sort(), ['soun', 'vide']);
  assert.deepEqual(boxTypes(data).slice(0, 3), ['ftyp', 'moov', 'sidx']);
  const media = await probeMedia(data, 'video/mp4');
  assert.ok(Math.abs(media.duration - state.manifestDuration) < 2, `duration ${media.duration} vs playlist ${state.manifestDuration}`);
  assert.ok(Math.abs(media.seekedTo - 15) < 1.5, `seek landed at ${media.seekedTo}`);
  assert.ok(media.audioBytes > 0 && media.videoBytes > 0, `not decoded: ${JSON.stringify(media)}`);
});

test('download: a long stream waits in IndexedDB, not RAM, and the storage is removed with the tab', async (t) => {
  const { state, data } = await downloadVia(`${ORIGIN}/big-hls/index.m3u8`, 'Big');
  assert.equal(state.state, 'done', JSON.stringify(state));
  assert.equal(state.storage, 'indexeddb');
  assert.ok(data.length > 60 * 1024 * 1024, `file only ${data.length} bytes`);
  assert.equal(data.length, state.size);
  assert.deepEqual(boxTypes(data).slice(0, 3), ['ftyp', 'moov', 'sidx']);
  assert.equal(boxTypes(data).filter(t => t === 'moof').length, 60);
  assert.equal(boxTypes(data).filter(t => t === 'free').length, 60, 'media data (incl. padding) was not carried over');
  assert.ok(Math.abs(state.duration - 120) < 3, `duration ${state.duration}`);
  t.diagnostic(`file ${(data.length / 1048576).toFixed(1)} MB, held at most ${(state.peakHeld / 1048576).toFixed(1)} MB, storage ${state.storage}`);
  // What the downloader itself held at once: a few segments, not the 61 MB file
  assert.ok(state.peakHeld < 12 * 1024 * 1024, `held ${(state.peakHeld / 1048576).toFixed(1)} MB at once`);
  // the tab's database is deleted when the tab closes (downloadVia closed it)
  const left = await until(async () => {
    const page = await ctx.newPage();
    await page.goto(`chrome-extension://${extId}/popup.html`);
    const names = await page.evaluate(async () => (await indexedDB.databases()).map(d => d.name).filter(n => n.startsWith('sap-download-')));
    await page.close();
    return names.length === 0 ? true : null;
  }, { timeout: 8000, interval: 500 });
  assert.ok(left, 'download databases were left behind');
});

test('browser start removes databases a crashed tab left behind, not the ones of open pages', async () => {
  const page = await ctx.newPage();
  await page.goto(`chrome-extension://${extId}/popup.html`);
  const old = Date.now() - 5 * 60 * 1000;
  const names = { crashed: `sap-download-${old}-crash`, cache: `sap-cache-${old}-crash`, live: `sap-download-${old}-live` };
  await page.evaluate(async (names) => {
    for (const name of Object.values(names)) {
      await new Promise((ok, bad) => { const r = indexedDB.open(name, 1); r.onupgradeneeded = () => r.result.createObjectStore('segments'); r.onsuccess = () => { r.result.close(); ok(); }; r.onerror = () => bad(r.error); });
    }
    navigator.locks.request(names.live, () => new Promise(() => {})); // an open download page
  }, names);
  const removed = await sw.evaluate(() => removeLeftoverDatabases());
  const left = await page.evaluate(async () => (await indexedDB.databases()).map(d => d.name).filter(n => n.startsWith('sap-')));
  await page.close();
  assert.equal(removed, 2);
  assert.ok(!left.includes(names.crashed) && !left.includes(names.cache), `left: ${left}`);
  assert.ok(left.includes(names.live), 'a database in use was removed');
});

test('download: a plain file is saved as it is', async () => {
  const { state, data, name } = await downloadVia(`${ORIGIN}/media/real.webm`, 'Plain');
  assert.equal(state.state, 'done', JSON.stringify(state));
  assert.equal(name, 'Plain.webm');
  assert.ok(data.equals(fs.readFileSync(path.join(__dirname, 'fixtures', 'clip.webm'))));
});

test('⬇️ in the page menu opens the downloader with the stream and its cleaned title', async () => {
  await setSettings({ showDownloadIcon: true, downloadMethod: 'browser' });
  const page = await openSite('/p/real-hls');
  await until(async () => (await readItems(page)).length === 1);
  await page.click('#video-handler-button');
  const [dl] = await Promise.all([ctx.waitForEvent('page'), page.click('.v-action-download')]);
  await until(() => dl.url().includes('download.html'));
  const params = new URL(dl.url()).searchParams;
  assert.equal(params.get('url'), `${ORIGIN}/hls-real/index.m3u8`);
  assert.equal(params.get('title'), 'Test Clip E02');
  await dl.close();
  await page.close();
});

// ── whole-video download while watching (src/stream-cache.mjs) ──────────────

const BIG = `${ORIGIN}/big-hls/index.m3u8`; // 60 segments, ~61 MB, 2 min

// Opens a player page, pauses it once it plays, waits until its cache has every segment
async function cacheRun(file, url, { timeout = 90000, title = 'Whole Video' } = {}) {
  const page = await ctx.newPage();
  await page.goto(`chrome-extension://${extId}/${file}?url=${encodeURIComponent(url)}&title=${encodeURIComponent(title)}`);
  await until(() => page.evaluate(() => { const v = document.querySelector('video'); return v && v.currentTime > 0.2; }), { timeout: 20000 });
  // Paused, the player buffers no further; the download must carry on to the end anyway
  await page.evaluate(() => document.querySelector('video').pause());
  const progress = await until(() => page.evaluate(() => window._cache && window._cache.progress().complete && window._cache.progress()), { timeout });
  // the badge follows within half a second
  await until(() => page.evaluate(() => { const b = document.querySelector('.sap-cache'); return !b || b.dataset.state === 'complete'; }), { timeout: 3000 });
  const info = await page.evaluate(() => {
    const v = document.querySelector('video');
    return {
      buffered: v.buffered.length ? v.buffered.end(v.buffered.length - 1) : 0,
      stats: window._cache.stats,
      badge: (document.querySelector('.sap-save') || {}).title || '',
      badgeState: (document.querySelector('.sap-cache') || { dataset: {} }).dataset.state
    };
  });
  return { page, progress, ...info };
}

// Presses the badge's Save button; returns the download page's result and the saved file
async function saveFromBadge(page) {
  // the control sits in the player's control bar (hidden while idle): press it directly
  const [dlPage] = await Promise.all([ctx.waitForEvent('page', { timeout: 15000 }), page.evaluate(() => document.querySelector('.sap-save').click())]);
  const download = await dlPage.waitForEvent('download', { timeout: 60000 });
  const file = path.join(os.tmpdir(), `sap-cache-${Date.now()}-${download.suggestedFilename()}`);
  await download.saveAs(file);
  const state = await dlPage.evaluate(() => window._download);
  const data = fs.readFileSync(file);
  fs.rmSync(file, { force: true });
  return { dlPage, state, data, name: download.suggestedFilename() };
}

for (const [name, file] of [['Vidstack/hls.js', 'player.html'], ['Shaka', 'player-shaka.html'], ['ArtPlayer/hls.js', 'player-art.html']]) {
  test(`whole video (${name}): downloads to the end while paused, each segment once; Save needs no second download`, async (t) => {
    await setSettings({ cacheWholeVideo: true, cacheLimitGB: 0, bufferAheadSeconds: 10, fastBufferingParallel: 4 });
    site.log.big.length = 0;
    const run = await cacheRun(file, BIG);
    t.diagnostic(`${name}: ${JSON.stringify({ progress: run.progress, buffered: run.buffered, stats: run.stats, badge: run.badge })}`);
    assert.equal(run.progress.total, 61, 'init + 60 segments planned');
    assert.ok(run.buffered < 60, `the player itself buffered only a window (${run.buffered} s)`);
    const counts = {};
    for (const u of site.log.big) counts[u] = (counts[u] || 0) + 1;
    assert.equal(Object.keys(counts).length, 60, 'every segment fetched');
    assert.ok(Object.values(counts).every(n => n === 1), `a segment was fetched twice: ${JSON.stringify(Object.entries(counts).filter(([, n]) => n > 1))}`);
    assert.equal(run.badgeState, 'complete');
    assert.match(run.badge, /Whole video loaded/);

    site.log.big.length = 0;
    const saved = await saveFromBadge(run.page);
    t.diagnostic(`save: ${JSON.stringify({ name: saved.name, size: saved.data.length, fromCache: saved.state.fromCache, fromNetwork: saved.state.fromNetwork })}`);
    assert.equal(saved.state.state, 'done');
    assert.equal(saved.name, 'Whole Video.mp4');
    assert.equal(site.log.big.length, 0, 'Save downloaded segments again');
    assert.equal(saved.state.fromCache, 61);
    assert.equal(saved.state.fromNetwork, 0);
    assert.equal(saved.state.stored, 0, 'cached segments were copied into the download page');
    assert.deepEqual(boxTypes(saved.data).slice(0, 3), ['ftyp', 'moov', 'sidx']);
    assert.ok(Math.abs(saved.state.duration - 120) < 3, `duration ${saved.state.duration}`);
    // once saved, a tap asks before writing another copy
    await until(() => run.page.evaluate(() => /^Saved/.test(document.querySelector('.sap-save').title)), { timeout: 10000 });
    const pages = ctx.pages().length;
    const again = await run.page.evaluate(() => {
      document.querySelector('.sap-save').click();
      const menu = document.querySelector('.sap-save-menu');
      const b = menu.querySelector('.sap-save-whole');
      return { open: !menu.hidden, label: b.hidden ? '' : b.textContent };
    });
    assert.deepEqual(again, { open: true, label: 'Save another copy' });
    await run.page.waitForTimeout(500);
    assert.equal(ctx.pages().length, pages, 'a second tap opened another download page');
    await saved.dlPage.close();
    await run.page.close();
  });
}

test('whole video: an unreliable server (503 / 429 on every segment) is retried until everything is in', async (t) => {
  await setSettings({ cacheWholeVideo: true, bufferAheadSeconds: 10 });
  site.log.flaky = {};
  const run = await cacheRun('player.html', `${ORIGIN}/flaky-hls/index.m3u8`, { timeout: 120000 });
  t.diagnostic(JSON.stringify({ progress: run.progress, stats: run.stats }));
  assert.equal(run.progress.total, 13);
  assert.ok(run.stats.failures > 0, 'the server never failed?');
  assert.equal(await run.page.evaluate(() => { const v = document.querySelector('video'); return !v.error; }), true);
  await run.page.close();
});

for (const [name, file] of [['Vidstack', 'player.html'], ['Shaka', 'player-shaka.html'], ['ArtPlayer', 'player-art.html']]) {
  test(`whole video (${name}): a plain file is cached as byte ranges, then plays from the local copy and saves as it is`, async () => {
    await setSettings({ cacheWholeVideo: true, bufferAheadSeconds: 0 });
    const run = await cacheRun(file, `${ORIGIN}/media/real.webm`, { title: 'Clip' });
    await until(() => run.page.evaluate(() => window._playingLocalCopy === true), { timeout: 10000 });
    const local = await run.page.evaluate(async () => {
      const v = document.querySelector('video');
      const t0 = v.currentTime;
      await v.play().catch(() => {});
      await new Promise(r => setTimeout(r, 1200));
      return { src: v.currentSrc.slice(0, 5), advanced: v.currentTime > t0, error: v.error && v.error.code };
    });
    assert.deepEqual(local, { src: 'blob:', advanced: true, error: null });
    await run.page.evaluate(() => document.querySelector('video').pause());
    const [download] = await Promise.all([run.page.waitForEvent('download', { timeout: 15000 }), run.page.evaluate(() => document.querySelector('.sap-save').click())]);
    const out = path.join(os.tmpdir(), `sap-file-${Date.now()}.webm`);
    await download.saveAs(out);
    assert.equal(download.suggestedFilename(), 'Clip.webm');
    assert.ok(fs.readFileSync(out).equals(fs.readFileSync(path.join(__dirname, 'fixtures', 'clip.webm'))), 'saved file differs from the original');
    fs.rmSync(out, { force: true });
    await run.page.close();
  });
}

for (const [name, file] of [['Vidstack/hls.js', 'player.html'], ['Shaka', 'player-shaka.html'], ['ArtPlayer/hls.js', 'player-art.html']]) {
  test(`whole video (${name}): one quality (closest to the screen) is played and downloaded; Save preselects it`, async (t) => {
    await setSettings({ cacheWholeVideo: true, bufferAheadSeconds: 10 });
    // the 720 px window asks for ~790 px: 720p, not 360p
    const run = await cacheRun(file, `${ORIGIN}/multi-hls/master.m3u8`, { title: 'Two Qualities' });
    const urls = await run.page.evaluate(() => window._cache.plan.map(i => i.url));
    t.diagnostic(JSON.stringify({ progress: run.progress, sample: urls.slice(0, 3) }));
    assert.equal(urls.length, 13);
    assert.ok(urls.filter(u => u.includes('.m4s')).every(u => u.endsWith('?q=high')), `not all 720p: ${urls}`);
    const saved = await saveFromBadge(run.page);
    const chosen = await saved.dlPage.evaluate(() => document.getElementById('quality').selectedOptions[0].textContent);
    assert.match(chosen, /^720p/);
    assert.equal(saved.state.fromNetwork, 0);
    await saved.dlPage.close();
    await run.page.close();
  });
}

for (const [name, file] of [['Shaka', 'player-shaka.html'], ['ArtPlayer/Shaka', 'player-art.html']]) {
  test(`whole video (${name}) DASH: video + audio downloaded completely; Save builds the MP4 from the cache`, async (t) => {
    await setSettings({ cacheWholeVideo: true, bufferAheadSeconds: 10 });
    const run = await cacheRun(file, `${ORIGIN}/dash-real/manifest.mpd`, { title: 'Dash Clip' });
    t.diagnostic(JSON.stringify({ progress: run.progress, stats: run.stats }));
    assert.equal(run.progress.total, 26, '2 init segments + 12 video + 12 audio segments');
    const saved = await saveFromBadge(run.page);
    assert.equal(saved.state.state, 'done', JSON.stringify(saved.state));
    assert.equal(saved.state.fromNetwork, 0);
    assert.deepEqual(saved.state.tracks.map(x => x.handler).sort(), ['soun', 'vide']);
    const media = await probeMedia(saved.data, 'video/mp4');
    assert.ok(Math.abs(media.duration - 24) < 1.5, `duration ${media.duration}`);
    assert.ok(media.audioBytes > 0 && media.videoBytes > 0, 'audio or video not decoded');
    await saved.dlPage.close();
    await run.page.close();
  });
}

test('ArtPlayer: the quality menu switches the quality, and the download follows it', async () => {
  await setSettings({ cacheWholeVideo: true, bufferAheadSeconds: 10 });
  const run = await cacheRun('player-art.html', `${ORIGIN}/multi-hls/master.m3u8`);
  const plan = () => run.page.evaluate(() => window._cache.plan.map(i => i.url).filter(u => u.includes('.m4s')));
  assert.ok((await plan()).every(u => u.endsWith('?q=high')));
  await run.page.mouse.move(400, 300);
  await run.page.click('.art-control-setting');
  await run.page.locator('.art-setting-item[data-name="sap-quality"]').click();
  const item = run.page.locator('.art-setting-item:not(.art-setting-item-back)', { hasText: /^\s*360p\s*$/ });
  await item.waitFor({ state: 'visible', timeout: 5000 });
  await item.click();
  const low = await until(async () => { const p = await plan(); return p.length && p.every(u => u.endsWith('?q=low')) ? p : null; }, { timeout: 10000 });
  assert.ok(low, `the download did not follow: ${JSON.stringify(await plan())}`);
  assert.ok(await until(() => run.page.evaluate(() => window._cache.progress().complete), { timeout: 20000 }));
  assert.equal(await run.page.evaluate(() => window._hls.currentLevel), 0);
  await run.page.evaluate(() => localStorage.clear()); // forget the 360p preference
  await run.page.close();
});

test('ArtPlayer: arrow keys seek 10 s, the screenshot button saves a PNG', async () => {
  const page = await ctx.newPage();
  await page.goto(`chrome-extension://${extId}/player-art.html?url=${encodeURIComponent(`${ORIGIN}/hls-real/index.m3u8`)}&title=Shot`);
  await until(() => page.evaluate(() => { const v = document.querySelector('video'); return v && v.readyState >= 3 && v.currentTime > 0.2; }), { timeout: 20000 });
  await page.evaluate(async () => { const v = document.querySelector('video'); v.pause(); v.currentTime = 2; await new Promise(r => setTimeout(r, 300)); });
  await page.keyboard.press('ArrowRight');
  const t = await until(() => page.evaluate(() => { const v = document.querySelector('video'); return v.currentTime >= 11.5 ? v.currentTime : null; }), { timeout: 5000 });
  assert.ok(t && t < 12.5, `ArrowRight went to ${t}`);
  await page.mouse.move(400, 300);
  const [download] = await Promise.all([page.waitForEvent('download', { timeout: 10000 }), page.click('.art-control-screenshot')]);
  assert.match(download.suggestedFilename(), /\.png$/);
  await page.close();
});

// Opens a player on the crawling stream (1.2 s per segment, 2 at a time) and pauses it
async function openLoading(file) {
  await setSettings({ cacheWholeVideo: true, bufferAheadSeconds: 10, fastBufferingParallel: 2 });
  const page = await ctx.newPage();
  await page.goto(`chrome-extension://${extId}/${file}?url=${encodeURIComponent(`${ORIGIN}/crawl-hls/index.m3u8`)}&title=${encodeURIComponent('Slow Clip')}`);
  await until(() => page.evaluate(() => window._cache && window._cache.progress().done >= 3), { timeout: 30000 });
  await page.evaluate(() => { const v = document.querySelector('video'); if (v) v.pause(); });
  return page;
}
const clickBadge = (page, cls) => page.evaluate((c) => document.querySelector(`.${c}`).click(), cls);

for (const [name, file] of [['Vidstack', 'player.html'], ['Shaka', 'player-shaka.html'], ['ArtPlayer', 'player-art.html']]) {
  test(`whole video (${name}): Save while loading → "Whole video" waits for the download, then saves without fetching again`, async (t) => {
    const page = await openLoading(file);
    assert.equal(await page.evaluate(() => window._cache.progress().complete), false, 'already complete: the test stream is too fast');
    await clickBadge(page, 'sap-save');
    const choices = await page.evaluate(() => { const m = document.querySelector('.sap-save-menu'); return m.hidden ? null : [...m.querySelectorAll('button')].filter(b => !b.hidden).map(b => b.textContent); });
    assert.deepEqual(choices, ['Save whole video', 'Save loaded part']);
    // nothing is drawn over the picture: the control is inside the player's control bar
    assert.equal(await page.evaluate(() => !!document.querySelector('.sap-cache').closest('media-community-skin, .shaka-controls-button-panel, .art-controls')), true);
    site.log.segments.length = 0;
    const dlPromise = ctx.waitForEvent('page', { timeout: 60000 });
    await clickBadge(page, 'sap-save-whole');
    assert.equal(await page.evaluate(() => document.querySelector('.sap-cache').dataset.state), 'pending');
    assert.match(await page.getAttribute('.sap-save', 'title'), /Will save when loaded/);
    const dlPage = await dlPromise;
    const opened = await page.evaluate(() => window._cache.progress());
    assert.equal(opened.complete, true, 'the download page opened before the video was loaded');
    const download = await dlPage.waitForEvent('download', { timeout: 60000 });
    const state = await dlPage.evaluate(() => window._download);
    t.diagnostic(JSON.stringify({ name: download.suggestedFilename(), fromCache: state.fromCache, fromNetwork: state.fromNetwork }));
    assert.equal(state.fromNetwork, 0);
    assert.equal(state.fromCache, 13);
    await dlPage.close();
    await page.close();
  });
}

test('whole video: Save while loading → "Loaded part" saves only what is loaded (from the cache)', async (t) => {
  const page = await openLoading('player-shaka.html');
  await clickBadge(page, 'sap-save');
  const [dlPage] = await Promise.all([ctx.waitForEvent('page', { timeout: 15000 }), clickBadge(page, 'sap-save-part')]);
  const download = await dlPage.waitForEvent('download', { timeout: 60000 });
  const state = await dlPage.evaluate(() => window._download);
  t.diagnostic(JSON.stringify({ name: download.suggestedFilename(), duration: state.duration, fromCache: state.fromCache, fromNetwork: state.fromNetwork }));
  assert.equal(state.partial, true);
  assert.equal(download.suggestedFilename(), 'Slow Clip (part).mp4');
  assert.equal(state.fromNetwork, 0);
  assert.ok(state.duration > 4 && state.duration < 22, `duration ${state.duration}`);
  await dlPage.close();
  await page.close();
});

test('popup: parallel downloads stays visible with faster buffering off, and the whole-video download uses it (8)', async () => {
  await setSettings({ cacheWholeVideo: true, fastBuffering: true, fastBufferingParallel: 4 });
  const popup = await ctx.newPage();
  await popup.goto(`chrome-extension://${extId}/popup.html`);
  await popup.click('#tab-player');
  await popup.click('label.toggle:has(#toggle-fast-buffering)'); // the switch drawn over the checkbox
  assert.equal(await popup.isChecked('#toggle-fast-buffering'), false);
  assert.equal(await popup.isVisible('#fast-buffering-parallel'), true);
  assert.equal(await popup.isVisible('#buffer-ahead'), true);
  await popup.selectOption('#fast-buffering-parallel', '8');
  await sleep(400);
  await popup.close();
  const page = await ctx.newPage();
  await page.goto(`chrome-extension://${extId}/player-art.html?url=${encodeURIComponent(`${ORIGIN}/hls-real/index.m3u8`)}`);
  assert.equal(await until(() => page.evaluate(() => window._cache && window._cache.maxParallel)), 8);
  await page.close();
  await setSettings({ fastBuffering: true, fastBufferingParallel: 4 });
});

test('whole video: off in the settings means no cache (and no badge)', async () => {
  await setSettings({ cacheWholeVideo: false });
  const page = await ctx.newPage();
  await page.goto(`chrome-extension://${extId}/player.html?url=${encodeURIComponent(`${ORIGIN}/hls-real/index.m3u8`)}`);
  await until(() => page.evaluate(() => { const v = document.querySelector('video'); return v && v.currentTime > 0.2; }), { timeout: 20000 });
  assert.equal(await page.evaluate(() => window._cache), null);
  assert.equal(await page.$('.sap-cache'), null);
  await page.close();
  await setSettings({ cacheWholeVideo: true, bufferAheadSeconds: 0 });
});

// ── settings ─────────────────────────────────────────────────────────────────

test('settings: blacklist, enabled, cleanNames and maxStreams', async () => {
  await setSettings({ blacklist: ['localhost'] });
  let page = await openSite('/p/video', { settle: 3000 });
  assert.equal((await readItems(page)).length, 0, 'blacklisted site still detected');
  await page.close();

  await setSettings({ blacklist: [], enabled: false });
  page = await openSite('/p/video', { settle: 3000 });
  assert.equal((await readItems(page)).length, 0, 'disabled extension still detected');
  await page.close();

  await setSettings({ enabled: true, cleanNames: false });
  page = await openSite('/p/early?raw', {});
  const raw = await until(async () => { const r = await readItems(page); return r.length ? r : null; });
  assert.equal(raw[0].name, 'early.m3u8');
  await page.close();

  await setSettings({ cleanNames: true, maxStreams: 1 });
  page = await openSite('/p/early?cap', {});
  await until(async () => (await readItems(page)).length === 1);
  await page.evaluate(() => { fetch('/hls/early.m3u8?a=1'); fetch('/master/master.m3u8'); });
  await sleep(2500);
  assert.equal((await readItems(page)).length, 1);
  await page.close();
  await setSettings({ maxStreams: 50 });
});

test('external player errors are reported (native without permission, VLC HTTP down)', async () => {
  const popup = await ctx.newPage();
  await popup.goto(`chrome-extension://${extId}/popup.html`);
  await setSettings({ desktopExternalMethod: 'native' });
  const native = await popup.evaluate(() => chrome.runtime.sendMessage({ type: 'openExternalPlayer', url: 'http://localhost:8099/media/a.mp4' }));
  assert.equal(native.success, false);
  assert.match(native.error, /nativeMessaging permission/);
  await setSettings({ desktopExternalMethod: 'vlc_http', vlcHttpPassword: 'x' });
  const vlc = await popup.evaluate(() => chrome.runtime.sendMessage({ type: 'openExternalPlayer', url: 'http://localhost:8099/media/a.mp4' }));
  assert.equal(vlc.success, false);
  await setSettings({ desktopExternalMethod: 'protocol' });
  await popup.close();
});

// ── floating button ──────────────────────────────────────────────────────────

const resetLayout = () => sw.evaluate(() => chrome.storage.local.remove('buttonLayout'));
const layoutOf = () => sw.evaluate(async () => (await chrome.storage.local.get('buttonLayout')).buttonLayout);

async function pageWithButton(route = '/p/video') {
  const page = await openSite(route);
  await page.locator('#video-handler-button').waitFor({ state: 'visible', timeout: 10000 });
  return page;
}

test('button: drag moves it, snaps to a side, remembers the spot per site and survives a reload', async () => {
  await resetLayout();
  const page = await pageWithButton();
  const box = await page.locator('#video-handler-button').boundingBox();
  assert.ok(box.x > 1100 && box.y > 600, 'starts in the bottom-right corner');
  await page.mouse.move(box.x + 24, box.y + 24);
  await page.mouse.down();
  await page.mouse.move(600, 300, { steps: 8 });
  await page.mouse.move(60, 150, { steps: 8 });
  await page.mouse.up();
  await sleep(300);

  const layout = await layoutOf();
  assert.equal(layout.sites.localhost.side, 'left');
  assert.ok(layout.sites.localhost.yRatio > 0.1 && layout.sites.localhost.yRatio < 0.35, JSON.stringify(layout));
  assert.equal(await page.locator('#video-handler-menu').isVisible(), false, 'ending a drag must not open the menu');
  const moved = await page.locator('#video-handler-button').boundingBox();
  assert.ok(moved.x < 100 && moved.y < 250, `snapped to the left edge: ${JSON.stringify(moved)}`);

  await page.reload();
  await page.locator('#video-handler-button').waitFor({ state: 'visible', timeout: 10000 });
  const again = await page.locator('#video-handler-button').boundingBox();
  assert.ok(again.x < 100, 'position restored after reload');
  await resetLayout();
  await page.close();
});

test('button: a plain click still toggles the menu', async () => {
  await resetLayout();
  const page = await pageWithButton();
  await page.click('#video-handler-button');
  assert.equal(await page.locator('#video-handler-menu').isVisible(), true);
  await sleep(350);
  await page.click('#video-handler-button');
  assert.equal(await page.locator('#video-handler-menu').isVisible(), false);
  await page.close();
});

test('button: the menu opens fully inside the viewport from all four corners', async () => {
  const page = await pageWithButton();
  const vp = page.viewportSize();
  for (const [side, yRatio] of [['left', 0], ['right', 0], ['left', 1], ['right', 1]]) {
    await sw.evaluate(l => chrome.storage.local.set({ buttonLayout: { global: l, sites: {} } }), { side, yRatio });
    await sleep(400);
    await page.click('#video-handler-button');
    const m = await page.locator('#video-handler-menu').boundingBox();
    assert.ok(m, `${side}/${yRatio}: menu not visible`);
    assert.ok(m.x >= 0 && m.y >= 0 && m.x + m.width <= vp.width && m.y + m.height <= vp.height, `${side}/${yRatio}: menu outside viewport ${JSON.stringify(m)}`);
    await sleep(350);
    await page.click('#video-handler-button');
    await sleep(350);
  }
  await resetLayout();
  await page.close();
});

test('button: popup corner select and reset change the position', async () => {
  await resetLayout();
  const page = await pageWithButton();
  const popup = await ctx.newPage();
  await popup.goto(`chrome-extension://${extId}/popup.html`);
  await popup.click('#tab-menu');
  await popup.selectOption('#button-corner', 'top-left');
  await sleep(500);
  const box = await page.locator('#video-handler-button').boundingBox();
  assert.ok(box.x < 100 && box.y < 100, `top-left applied live: ${JSON.stringify(box)}`);
  await popup.click('#reset-button-position');
  await sleep(500);
  const back = await page.locator('#video-handler-button').boundingBox();
  assert.ok(back.x > 1100 && back.y > 600, `reset to bottom-right: ${JSON.stringify(back)}`);
  assert.deepEqual(await layoutOf(), { global: { side: 'right', yRatio: 1 }, sites: {} });
  await popup.close();
  await page.close();
});

test('button: visibility "never" hides it, "fade" dims it when idle and wakes on hover', async () => {
  await setSettings({ buttonVisibility: 'never' });
  let page = await openSite('/p/video', { settle: 3000 });
  assert.equal(await page.locator('#video-handler-button').isVisible(), false, 'never');
  await page.close();

  await setSettings({ buttonVisibility: 'fade' });
  page = await pageWithButton();
  const faded = () => page.evaluate(() => document.getElementById('video-handler-button').classList.contains('v-faded'));
  assert.equal(await faded(), false, 'awake at first');
  await sleep(3600);
  assert.equal(await faded(), true, 'faded after idle');
  await page.hover('#video-handler-button');
  assert.equal(await faded(), false, 'wakes on hover');
  await page.close();
  await setSettings({ buttonVisibility: 'always' });
});

test('button: hidden while an element is fullscreen', async () => {
  const page = await pageWithButton();
  await page.evaluate(() => {
    const b = document.createElement('button');
    b.id = 'fs-test';
    b.textContent = 'fs';
    b.onclick = () => document.documentElement.requestFullscreen();
    document.body.appendChild(b);
  });
  await page.click('#fs-test');
  await until(() => page.evaluate(() => !!document.fullscreenElement));
  await sleep(300);
  const display = () => page.evaluate(() => document.getElementById('video-handler-button').style.display);
  assert.equal(await display(), 'none');
  await page.evaluate(() => document.exitFullscreen());
  await until(async () => (await display()) === 'flex');
  assert.equal(await display(), 'flex');
  await page.close();
});

// ── real streams (internet) ──────────────────────────────────────────────────

const MUX = 'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8';
const DASH = 'https://dash.akamaized.net/akamai/bbb_30fps/bbb_30fps.mpd';

for (const [name, file, selector, url] of [
  ['Vidstack HLS', 'player.html', 'video', MUX],
  ['Shaka HLS', 'player-shaka.html', '#video', MUX],
  ['Shaka DASH', 'player-shaka.html', '#video', DASH],
  ['Vidstack link with DASH (redirects to Shaka)', 'player.html', '#video', DASH]
]) {
  test(`plays ${name}`, { skip: !NETWORK && 'set E2E_NETWORK=1' }, async () => {
    const page = await ctx.newPage();
    await page.goto(`chrome-extension://${extId}/${file}?url=${encodeURIComponent(url)}`);
    const ok = await until(() => page.evaluate(s => { const v = document.querySelector(s); return v && v.currentTime > 0.5 && v.videoWidth > 0; }, selector), { timeout: 25000 });
    assert.ok(ok, `${name} did not start playing`);
    await page.close();
  });
}

test('Shaka loads VTT and SRT subtitles passed by the extension', { skip: !NETWORK && 'set E2E_NETWORK=1' }, async () => {
  const subs = [{ url: `${ORIGIN}/subs/en.vtt`, label: 'English', lang: 'en' }, { url: `${ORIGIN}/subs/fr.srt`, label: 'French', lang: 'fr' }];
  const page = await ctx.newPage();
  await page.goto(`chrome-extension://${extId}/player-shaka.html?url=${encodeURIComponent(MUX)}&subs=${encodeURIComponent(JSON.stringify(subs))}`);
  const tracks = await until(() => page.evaluate(() => window._shakaPlayer && window._shakaPlayer.getTextTracks().length === 2 ? window._shakaPlayer.getTextTracks().map(t => t.label) : null), { timeout: 25000 });
  assert.deepEqual(tracks, ['English', 'French']);
  await until(() => page.evaluate(() => window._shakaPlayer.getTextTracks().some(t => t.active && t.label === 'English')));
  await page.locator('#btn-cc').waitFor({ state: 'visible' });
  await page.keyboard.press('c'); // cycles to the next caption track
  await sleep(300);
  assert.equal(await page.evaluate(() => window._shakaPlayer.getTextTracks().find(t => t.active).label), 'French');
  await page.close();
});

// ── Audio effects (src/audio-fx.mjs, src/audio-dsp.mjs, src/audio-ui.mjs) ──────────────────
// levels.wav: 3 s loud (−6 dBFS) then 12 s quiet (−36 dBFS) voice-like sound, from another
// host and without CORS headers
const LEVELS = `http://127.0.0.1:8099/media/levels.wav`;
const setAudio = v => sw.evaluate(async (a) => { if (a) await chrome.storage.local.set({ audioFx: a }); else await chrome.storage.local.remove('audioFx'); }, v);
const fxStatus = page => page.evaluate(() => {
  const s = window._audioFx.status();
  return { mode: s.mode, preset: s.settings.preset, boost: s.settings.boost, ctx: s.contextState, latency: s.latency };
});
const dB = x => 20 * Math.log10(x + 1e-9);
async function openAudio(file, url = LEVELS) {
  const page = await ctx.newPage();
  await page.goto(`chrome-extension://${extId}/${file}?url=${encodeURIComponent(url)}&title=Levels`);
  await until(() => page.evaluate(() => !!window._audioFx && !!document.querySelector('.sap-audio-btn')), { timeout: 20000 });
  return page;
}
// gain through the effects (output vs input level, dB) over `ms`, starting at time `at`
// (`volume` < 1 makes a constant-level source "quiet": the element volume applies before Web Audio)
async function gainAt(page, at, settle, ms = 1500, volume = 1) {
  await page.evaluate(([t, v]) => { const m = document.querySelector('video, audio'); m.volume = v; m.currentTime = t; return m.play(); }, [at, volume]);
  await sleep(settle);
  const r = await page.evaluate(ms => window._audioFx.measure(ms), ms);
  return { gain: dB(r.out.rms) - dB(r.in.rms), out: r.out, in: r.in };
}

// Vidstack lays out audio-only files with its audio skin (controls off-screen on this page), so it
// gets the HLS fixture (video + a full-scale 440 Hz audio rendition) made quiet by the volume.
const QUIET = 0.0316; // −30 dB
for (const [name, file, url, loudAt, quietAt] of [
  ['Vidstack', 'player.html', `${ORIGIN}/hls-real/master.m3u8`, [1, 1], [4, QUIET]],
  ['Shaka', 'player-shaka.html', LEVELS, [0.2, 1], [5, 1]],
  ['ArtPlayer', 'player-art.html', LEVELS, [0.2, 1], [5, 1]]
]) {
  test(`audio effects (${name}): nothing runs while Off; Dialogue lifts quiet speech after a loud part; boost; Off routes around`, async (t) => {
    await setAudio(null);
    const page = await openAudio(file, url);
    assert.deepEqual(await fxStatus(page).then(s => [s.mode, s.ctx]), ['off', 'none'], 'no AudioContext while Off');
    // the button sits in the player's control bar
    assert.equal(await page.evaluate(() => !!document.querySelector('.sap-audio').closest('media-community-skin, .shaka-controls-button-panel, .art-controls')), true);
    // real clicks: open the panel, choose Dialogue
    await page.evaluate(() => { const c = document.querySelector('.art-video-player, .shaka-controls-container, media-community-skin'); if (c) c.classList.add('art-control-show', 'art-hover'); });
    await page.click('.sap-audio-btn', { force: true });
    assert.equal(await page.isVisible('.sap-audio-menu'), true);
    await page.click('.sap-audio-menu [data-preset="dialogue"]');
    assert.equal(await page.getAttribute('.sap-audio-menu [data-preset="dialogue"]', 'aria-checked'), 'true');
    await page.evaluate(() => document.querySelector('video, audio').play());
    const active = await until(() => fxStatus(page).then(s => s.mode === 'active' && s.ctx === 'running'), { timeout: 10000 });
    assert.ok(active, JSON.stringify(await fxStatus(page)));
    assert.equal(await until(() => sw.evaluate(async () => ((await chrome.storage.local.get('audioFx')).audioFx || {}).preset)), 'dialogue', 'choice remembered');

    const loud = await gainAt(page, loudAt[0], 800, 1500, loudAt[1]);
    const quiet = await gainAt(page, quietAt[0], 4000, 1500, quietAt[1]);
    const status = await page.textContent('.sap-audio-status');
    t.diagnostic(JSON.stringify({ loud: loud.gain.toFixed(1), quiet: quiet.gain.toFixed(1), outLoudPeak: loud.out.peak.toFixed(3), status, latencyMs: Math.round((await fxStatus(page)).latency * 1000) }));
    assert.ok(loud.gain < 0, `loud part turned down (${loud.gain.toFixed(1)} dB)`);
    assert.ok(quiet.gain > 8, `quiet part lifted (${quiet.gain.toFixed(1)} dB)`);
    assert.ok(loud.out.peak <= 0.9, `no clipping (${loud.out.peak})`);
    assert.match(status, /Leveler [+−]/);

    // Music (no leveling) at 200 %: the quiet part comes out 6 dB louder
    await page.evaluate(() => window._audioFx.set({ preset: 'music', boost: 2 }));
    const boosted = await gainAt(page, 6, 700, 1500, quietAt[1]);
    assert.ok(Math.abs(boosted.gain - 6) < 1, `boost 200 % = ${boosted.gain.toFixed(1)} dB`);

    // Off: the worklet is dropped and the audio goes straight out
    await page.evaluate(() => window._audioFx.set({ preset: 'off', boost: 1 }));
    assert.equal((await fxStatus(page)).mode, 'bypass');
    const plain = await gainAt(page, 6, 500, 1500, quietAt[1]);
    assert.ok(Math.abs(plain.gain) < 0.5, `bypass changes nothing (${plain.gain.toFixed(2)} dB)`);
    assert.ok(plain.in.rms > 0.002, 'audio is not silent (cross-origin file without CORS headers)');

    // paused → the AudioContext is suspended (no audio work)
    await page.evaluate(() => document.querySelector('video, audio').pause());
    assert.ok(await until(() => fxStatus(page).then(s => s.ctx === 'suspended'), { timeout: 5000 }), 'context suspended while paused');
    await page.close();
  });
}

// Website audio effects run in the content script's isolated world: read through the extension
const tabOf = (page) => sw.evaluate(async (u) => (await chrome.tabs.query({})).find(t => t.url === u).id, page.url());
const siteElements = (tabId) => sw.evaluate(async (id) => {
  const [r] = await chrome.scripting.executeScript({ target: { tabId: id }, func: () => globalThis.__sapAudio && globalThis.__sapAudio.elements() });
  return r.result;
}, tabId);
const siteMeasure = (tabId, el) => sw.evaluate(async ([id, e]) => {
  const [r] = await chrome.scripting.executeScript({ target: { tabId: id }, func: (x) => globalThis.__sapAudio.measure(1000, x), args: [e] });
  return r.result;
}, [tabId, el]);
const corsRules = () => sw.evaluate(async () => (await chrome.declarativeNetRequest.getSessionRules()).map(r => r.id).filter(id => id >= 1e9 && id < 1.9e9));
const storedPreset = () => sw.evaluate(async () => ((await chrome.storage.local.get('audioFx')).audioFx || {}).preset);

test('audio effects on websites: media from another server without CORS headers, in a closed shadow root and in <audio> is processed; a server refusing CORS keeps its sound; nothing is added to the page', async (t) => {
  await setAudio({ preset: 'night' });
  const page = await openSite('/p/fx-everywhere');
  try {
    await page.evaluate(() => window._playAll());
    const tabId = await tabOf(page);
    await sleep(800);
    assert.deepEqual(await siteElements(tabId), [], 'nothing while the setting is off');
    assert.deepEqual(await corsRules(), []);

    await setSettings({ webAudioFx: true });
    const by = await until(async () => {
      const m = Object.fromEntries((await siteElements(tabId)).map(e => [e.id, e]));
      return m.other && m.other.mode === 'active' && m.shadow && m.shadow.mode === 'active' && m.refuse && m.refuse.noCors ? m : null;
    }, { timeout: 20000 });
    assert.ok(by, JSON.stringify(await siteElements(tabId)));
    assert.deepEqual(await corsRules(), [1e9 + tabId], 'CORS rule for this tab');
    for (const id of ['other', 'shadow']) {
      const r = await siteMeasure(tabId, id);
      t.diagnostic(`${id}: ${JSON.stringify(r)}`);
      assert.ok(r.in.rms > 0.001, `${id}: Web Audio hears the file (not silenced by CORS)`);
      assert.ok(r.out.rms > 0.001, `${id}: and plays it through the effects`);
    }
    const media = await page.evaluate(() => [document.getElementById('other'), window._shadowAudio, document.getElementById('refuse')]
      .map(m => ({ paused: m.paused, time: m.currentTime, cors: m.getAttribute('crossorigin') })));
    t.diagnostic(JSON.stringify(media));
    assert.ok(media.every(m => !m.paused && m.time > 0), 'all three keep playing');
    assert.deepEqual(media.map(m => m.cors), ['anonymous', 'anonymous', null], 'the refusing server got its element back as it was');
    assert.equal(await page.evaluate(() => [...document.querySelectorAll('*')].some(e => e.shadowRoot && e.shadowRoot.querySelector('.sap-audio, .t'))), false, 'no audio control added to the page');
    assert.deepEqual(await sw.evaluate(id => chrome.action.getBadgeBackgroundColor({ tabId: id }), tabId), [126, 87, 194, 255], 'badge shows effects running');

    // the Alt+Shift+A handler: next preset (Night → Music) and a toast
    await sw.evaluate(id => cycleAudioPreset({ id }), tabId);
    assert.equal(await storedPreset(), 'music');
    assert.ok(await until(() => page.evaluate(() => [...document.documentElement.children]
      .some(e => e.shadowRoot && (e.shadowRoot.querySelector('.t.show') || {}).textContent === 'Audio: Music'))), 'toast shown');

    await setSettings({ webAudioFx: false });
    assert.ok(await until(async () => (await corsRules()).length === 0), 'CORS rule removed when switched off');
    assert.ok(await until(async () => (await siteElements(tabId)).every(e => e.mode !== 'active')), 'effects off');
  } finally {
    await page.close();
    await setSettings({ webAudioFx: false });
    await setAudio(null);
  }
});

test('popup Audio tab: live status of the page, a preset chosen there reaches it', async () => {
  await setAudio({ preset: 'night' });
  await setSettings({ webAudioFx: true });
  const page = await openSite('/p/fx-everywhere');
  try {
    await page.evaluate(() => window._playAll());
    const tabId = await tabOf(page);
    const popup = await ctx.newPage();
    await popup.goto(`chrome-extension://${extId}/popup.html?tabId=${tabId}`);
    await popup.click('#tab-audio');
    assert.equal(await popup.isChecked('#toggle-web-audio'), true);
    const status = await until(() => popup.textContent('#audio-panel .sap-audio-status').then(s => (/Leveler|On/.test(s) ? s : null)), { timeout: 20000 });
    assert.ok(status, `status: ${await popup.textContent('#audio-panel .sap-audio-status')}`);
    assert.equal(await popup.isHidden('#audio-capture'), true, 'no tab capture offered while the page works');
    await popup.click('#audio-panel [data-preset="dialogue"]');
    assert.equal(await until(() => storedPreset().then(p => p === 'dialogue' && p)), 'dialogue');
    assert.equal(await popup.getAttribute('#audio-panel [data-preset="dialogue"]', 'aria-checked'), 'true');
    await popup.close();
  } finally {
    await page.close();
    await setSettings({ webAudioFx: false });
    await setAudio(null);
  }
});

test('audio effects: the popup default reaches an open player; Shift+↑ boosts, "a" cycles presets; HLS (MSE) audio is processed', async (t) => {
  await setAudio(null);
  const page = await openAudio('player-art.html', `${ORIGIN}/hls-real/master.m3u8`);
  await page.click('.sap-audio-btn', { force: true }); // a user gesture (autoplay policy)
  await page.evaluate(() => document.querySelector('video').play());
  const popup = await ctx.newPage();
  await popup.goto(`chrome-extension://${extId}/popup.html`);
  await popup.click('#tab-audio');
  await popup.click('#audio-panel [data-preset="night"]');
  await popup.locator('#audio-panel input[data-key="boost"]').evaluate((el) => { el.value = '150'; el.dispatchEvent(new Event('input', { bubbles: true })); });
  const got = await until(() => fxStatus(page).then(s => (s.preset === 'night' && s.boost === 1.5 && s.mode === 'active' ? s : null)), { timeout: 10000 });
  assert.ok(got, JSON.stringify(await fxStatus(page)));
  await popup.close();
  const r = await page.evaluate(() => window._audioFx.measure(1000));
  t.diagnostic(JSON.stringify(r));
  assert.ok(r.out.rms > 0.002, 'HLS audio comes through the effects');
  // keys (the panel is closed so they reach the page)
  await page.keyboard.press('Escape');
  await page.keyboard.press('Shift+ArrowUp');
  assert.equal((await fxStatus(page)).boost, 1.6);
  await page.keyboard.press('a');
  assert.equal((await fxStatus(page)).preset, 'music');
  // the popup shows the player's choice next time
  const popup2 = await ctx.newPage();
  await popup2.goto(`chrome-extension://${extId}/popup.html`);
  await popup2.click('#tab-audio');
  await until(() => popup2.getAttribute('#audio-panel [data-preset="music"]', 'aria-checked').then(v => v === 'true'));
  assert.equal(await popup2.getAttribute('#audio-panel [data-preset="music"]', 'aria-checked'), 'true');
  assert.equal(await popup2.inputValue('#audio-panel input[data-key="boost"]'), '160');
  await popup2.close();
  await page.close();
  await setAudio(null);
});

// Presets: a moved slider marks the preset "*"; save into it, save as new (typed name), rename,
// delete, restore a built-in — in each player's own panel, with real clicks and keys
const storedFx = () => sw.evaluate(async () => (await chrome.storage.local.get('audioFx')).audioFx || {});
const slide = (page, sel, key, v) => page.locator(`${sel} input[data-key="${key}"]`).evaluate((el, x) => { el.value = String(x); el.dispatchEvent(new Event('input', { bubbles: true })); }, v);
for (const [name, file, url] of [
  ['Vidstack', 'player.html', `${ORIGIN}/hls-real/master.m3u8`],
  ['Shaka', 'player-shaka.html', LEVELS],
  ['ArtPlayer', 'player-art.html', LEVELS]
]) {
  test(`audio presets (${name}): "Cinema*" after a change; save as new, rename, delete, save to Cinema, restore`, async () => {
    await setAudio({ preset: 'cinema' });
    const page = await openAudio(file, url);
    const M = '.sap-audio-menu';
    const chipText = id => page.textContent(`${M} [data-preset="${id}"]`);
    try {
      await page.evaluate(() => { const c = document.querySelector('.art-video-player, .shaka-controls-container, media-community-skin'); if (c) c.classList.add('art-control-show', 'art-hover'); });
      await page.click('.sap-audio-btn', { force: true });
      // the player may still be loading its source (a play() then is interrupted): retry
      assert.ok(await until(() => page.evaluate(() => document.querySelector('video, audio').play().then(() => true, () => false))), 'playing');
      assert.equal(await chipText('cinema'), 'Cinema');

      // a change: still Cinema, marked; nothing saved yet
      await slide(page, M, 'bass', 6);
      assert.equal(await chipText('cinema'), 'Cinema*');
      assert.equal(await page.getAttribute(`${M} [data-preset="cinema"]`, 'aria-checked'), 'true');
      assert.match(await page.textContent(`${M} .sap-audio-hint`), /Changed from Cinema/);
      assert.deepEqual(await page.$$eval(`${M} .sap-audio-actions [data-act]`, bs => bs.map(b => b.dataset.act)), ['save', 'new', 'reset']);

      // Save as new: the name is typed for real (a space must not pause the video)
      await page.click(`${M} [data-act="new"]`);
      assert.equal(await page.inputValue(`${M} .sap-audio-name-input`), 'Cinema 2');
      assert.equal(await page.evaluate(() => document.activeElement.className), 'sap-audio-name-input');
      await page.keyboard.press('Control+A');
      await page.keyboard.type('Late night');
      assert.equal(await page.evaluate(() => document.querySelector('video, audio').paused), false, 'typing reached the player');
      await page.keyboard.press('Enter');
      const fx = await until(() => storedFx().then(f => (f.preset && f.preset.startsWith('u') ? f : null)));
      assert.ok(fx, JSON.stringify(await storedFx()));
      assert.equal(fx.presets[fx.preset].name, 'Late night');
      assert.equal(fx.presets[fx.preset].bass, 6);
      assert.equal(fx.edits, null);
      const id = fx.preset;
      assert.equal(await chipText(id), 'Late night');
      assert.equal(await page.getAttribute(`${M} [data-preset="${id}"]`, 'aria-checked'), 'true');
      assert.equal(await page.evaluate(i => document.activeElement.dataset.preset, id), id, 'focus on the new preset');
      assert.equal(await chipText('cinema'), 'Cinema', 'Cinema itself unchanged');
      assert.equal(await page.evaluate(() => window._audioFx.status().params.bass), 6);

      // Rename to a taken name: refused in place; Escape closes only the name field
      await page.click(`${M} [data-act="rename"]`);
      await page.keyboard.press('Control+A');
      await page.keyboard.type('cinema');
      await page.keyboard.press('Enter');
      assert.equal(await page.textContent(`${M} .sap-audio-error`), 'That name is already used');
      assert.equal(await page.getAttribute(`${M} .sap-audio-name-input`, 'aria-invalid'), 'true');
      await page.keyboard.press('Escape');
      assert.equal(await page.isVisible(`${M} .sap-audio-name`), false);
      assert.equal(await page.isVisible(M), true, 'the panel stays open');
      await page.click(`${M} [data-act="rename"]`);
      await page.fill(`${M} .sap-audio-name-input`, 'Movies');
      await page.click(`${M} [data-act="name-ok"]`);
      assert.equal(await until(() => storedFx().then(f => f.presets && f.presets[id] && f.presets[id].name === 'Movies')), true);
      assert.equal(await chipText(id), 'Movies');

      // Delete needs a second tap; the sound keeps playing as an unsaved Custom
      await page.click(`${M} [data-act="delete"]`);
      assert.equal(await page.textContent(`${M} [data-act="delete"]`), 'Delete “Movies”?');
      assert.equal(await page.$(`${M} [data-preset="${id}"]`) != null, true);
      await page.click(`${M} [data-act="delete"]`);
      assert.equal(await page.$(`${M} [data-preset="${id}"]`), null);
      assert.equal(await chipText('custom'), 'Custom*');
      assert.equal(await page.evaluate(() => window._audioFx.status().params.bass), 6);

      // Save to Cinema, then Restore default
      await page.click(`${M} [data-preset="cinema"]`);
      await slide(page, M, 'treble', -3);
      await page.click(`${M} [data-act="save"]`);
      assert.equal(await chipText('cinema'), 'Cinema');
      assert.match(await page.textContent(`${M} .sap-audio-hint`), /Your version of Cinema/);
      assert.equal((await until(() => storedFx().then(f => f.presets && f.presets.cinema))).treble, -3);
      await page.click(`${M} [data-act="restore"]`);
      assert.equal(await until(() => storedFx().then(f => !(f.presets || {}).cinema)), true);
      assert.equal(await page.evaluate(() => window._audioFx.status().params.treble), 1);
      assert.equal(await page.isVisible(`${M} .sap-audio-actions`), false);
    } finally {
      await page.close();
      await setAudio(null);
    }
  });
}

test('audio presets: a preset saved in the popup reaches an open player; Alt+Shift+A includes it', async () => {
  await setAudio({ preset: 'night' });
  const page = await openAudio('player-art.html');
  const popup = await ctx.newPage();
  try {
    await popup.goto(`chrome-extension://${extId}/popup.html`);
    await popup.click('#tab-audio');
    await until(() => popup.getAttribute('#audio-panel [data-preset="night"]', 'aria-checked').then(v => v === 'true'));
    await slide(popup, '#audio-panel', 'dialogue', 10);
    assert.equal(await popup.textContent('#audio-panel [data-preset="night"]'), 'Night*');
    await until(() => page.evaluate(() => window._audioFx.status().params.dialogue === 10));
    await popup.click('#audio-panel [data-act="new"]');
    await popup.fill('#audio-panel .sap-audio-name-input', 'Quiet talk');
    await popup.press('#audio-panel .sap-audio-name-input', 'Enter');
    const id = await until(() => page.evaluate(() => { const s = window._audioFx.settings; return s.preset.startsWith('u') && s.presets[s.preset].name === 'Quiet talk' ? s.preset : null; }));
    assert.ok(id, 'the player follows the popup');
    // the player's own panel lists it, selected
    await page.click('.sap-audio-btn', { force: true });
    assert.equal(await page.textContent(`.sap-audio-menu [data-preset="${id}"]`), 'Quiet talk');
    assert.equal(await page.getAttribute(`.sap-audio-menu [data-preset="${id}"]`, 'aria-checked'), 'true');
    // the shortcut cycles Music → the user's preset → Off
    await sw.evaluate(() => setAudioPreset('music'));
    await sw.evaluate(() => cycleAudioPreset(null));
    assert.equal((await storedFx()).preset, id);
    await sw.evaluate(() => cycleAudioPreset(null));
    assert.equal((await storedFx()).preset, 'off');
  } finally {
    await popup.close();
    await page.close();
    await setAudio(null);
    await setSettings({ webAudioFx: false }); // setAudioPreset switched it on
  }
});
